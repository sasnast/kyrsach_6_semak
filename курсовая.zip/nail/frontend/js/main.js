// Rose Nail Studio - Главный файл
let currentUser = null;
let token = null;

// Кеш для данных
let cache = {
    services: null,
    masters: null,
    promotions: null,
    extraServices: null
};

// API функции
const API = {
    async request(endpoint, options = {}) {
        const headers = { 'Content-Type': 'application/json' };
        if (token) headers['Authorization'] = `Bearer ${token}`;
        
        const response = await fetch(`/api${endpoint}`, { ...options, headers });
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Ошибка запроса');
        }
        return response.json();
    },
    async getMyAppointments() {
    return this.request('/appointments/my');
},
async getMasterReviews(masterId) {
    return this.request(`/masters/${masterId}/reviews`);
},

async addReview(masterId, rating, comment) {
    return this.request(`/masters/${masterId}/reviews`, {
        method: 'POST',
        body: JSON.stringify({ rating, comment })
    });
},
async cancelAppointment(id) {
    return this.request(`/appointments/${id}/cancel`, { method: 'PUT' });
},
// Управление услугами
async getAdminServices() {
    return this.request('/admin/services');
},

async addService(data) {
    return this.request('/admin/services', { method: 'POST', body: JSON.stringify(data) });
},

async updateService(id, data) {
    return this.request(`/admin/services/${id}`, { method: 'PUT', body: JSON.stringify(data) });
},

async deleteService(id) {
    return this.request(`/admin/services/${id}`, { method: 'DELETE' });
},

// Управление ценами
async getAdminPrices() {
    return this.request('/admin/prices');
},

async updatePrice(id, price) {
    return this.request(`/admin/prices/${id}`, { method: 'PUT', body: JSON.stringify({ price }) });
},

async addPrice(data) {
    return this.request('/admin/prices', { method: 'POST', body: JSON.stringify(data) });
},
    async register(data) {
        return this.request('/auth/register', { method: 'POST', body: JSON.stringify(data) });
    },
    
    async login(login, password) {
        const data = await this.request('/auth/login', { method: 'POST', body: JSON.stringify({ login, password }) });
        token = data.token;
        currentUser = data.user;
        localStorage.setItem('token', token);
        localStorage.setItem('user', JSON.stringify(currentUser));
        return data;
    },
    
    async getMasters() {
        if (cache.masters) return cache.masters;
        cache.masters = await this.request('/masters');
        return cache.masters;
    },
    
    async getServices() {
        if (cache.services) return cache.services;
        cache.services = await this.request('/services');
        return cache.services;
    },
    
    async getExtraServices() {
        if (cache.extraServices) return cache.extraServices;
        cache.extraServices = await this.request('/services/extra');
        return cache.extraServices;
    },
    
    async getPromotions() {
        if (cache.promotions) return cache.promotions;
        cache.promotions = await this.request('/promotions');
        return cache.promotions;
    },
    
    async getMasterAvailableSlots(masterId, date) {
        return this.request(`/masters/${masterId}/available?date=${date}`);
    },
    
    async createAppointment(data) {
        return this.request('/appointments', { method: 'POST', body: JSON.stringify(data) });
    },
    
    async getAdminStats() {
        return this.request('/admin/stats');
    },
    
    async getAdminAppointments() {
        return this.request('/admin/appointments');
    },
    
    async getAdminMasters() {
        return this.request('/admin/masters');
    },
    
    async getAdminPromotions() {
        return this.request('/admin/promotions');
    },
    
    async getAdminClients() {
        return this.request('/admin/clients');
    },
    async getPrice(serviceId, levelId) {
    return this.request(`/services/price/${serviceId}/${levelId}`);
},
    logout() {
        token = null;
        currentUser = null;
        localStorage.clear();
        cache = { services: null, masters: null, promotions: null, extraServices: null };
    }
};

// Инициализация
function init() {
    const savedToken = localStorage.getItem('token');
    const savedUser = localStorage.getItem('user');
    if (savedToken && savedUser) {
        token = savedToken;
        currentUser = JSON.parse(savedUser);
    }
    updateUI();
    showPage('index');
}

function updateUI() {
    const authBtns = document.getElementById('authButtons');
    const userMenu = document.getElementById('userMenu');
    const adminLink = document.getElementById('adminLink');
    const myAppointmentsLink = document.getElementById('myAppointmentsLink');
    const userName = document.getElementById('userName');
    
    if (currentUser) {
        if (authBtns) authBtns.style.display = 'none';
        if (userMenu) userMenu.style.display = 'flex';
        if (userName) userName.textContent = currentUser.client_name || currentUser.login;
        if (adminLink && currentUser.role_id === 1) adminLink.style.display = 'block';
        else if (adminLink) adminLink.style.display = 'none';
        
        // Показываем пункт "Мои записи" для всех авторизованных пользователей
        if (myAppointmentsLink) myAppointmentsLink.style.display = 'block';
    } else {
        if (authBtns) authBtns.style.display = 'flex';
        if (userMenu) userMenu.style.display = 'none';
        if (adminLink) adminLink.style.display = 'none';
        if (myAppointmentsLink) myAppointmentsLink.style.display = 'none';
    }
}

// Навигация
async function showPage(page) {
    const container = document.getElementById('main-content');
    container.innerHTML = '<div style="text-align:center;padding:50px;">⏳ Загрузка...</div>';
    
    try {
        if (page === 'index') await renderIndex(container);
        else if (page === 'services') await renderServices(container);
        else if (page === 'masters') await renderMasters(container);
        else if (page === 'booking') await renderBooking(container);
        else if (page === 'myAppointments') await renderMyAppointments(container);  // НОВЫЙ ПУНКТ
        else if (page === 'promotions') await renderPromotions(container);
        else if (page === 'admin') {
    if (currentUser && currentUser.role_id === 1) {
        await window.renderAdmin(container);
    } else {
        container.innerHTML = '<div class="card"><h3>🔒 Доступ запрещен. Требуются права администратора.</h3></div>';
    }
}
    } catch (error) {
        container.innerHTML = `<div class="card"><h3>❌ Ошибка: ${error.message}</h3></div>`;
    }
    
    document.querySelectorAll('[data-page]').forEach(link => {
        link.classList.remove('active');
        if (link.dataset.page === page) link.classList.add('active');
    });
}

// Главная
async function renderIndex(container) {
    const promotions = await API.getPromotions();
    container.innerHTML = `
        <div class="hero">
            <h1>Добро пожаловать в Rose Nail Studio</h1>
            <p>Профессиональный маникюр и педикюр в уютной атмосфере</p>
            <button class="btn-primary" onclick="showPage('booking')">Записаться онлайн</button>
        </div>
        <div class="features">
            <div class="feature-card"><i class="fas fa-medal"></i><h3>Профессионалы</h3><p>Сертифицированные мастера с опытом от 5 лет</p></div>
            <div class="feature-card"><i class="fas fa-leaf"></i><h3>Премиум материалы</h3><p>Только лучшие бренды</p></div>
            <div class="feature-card"><i class="fas fa-clock"></i><h3>Удобное время</h3><p>Работаем с 9:00 до 21:00</p></div>
        </div>
        ${promotions.length ? `
        <h2 class="section-title">🎁 Акции</h2>
        <div class="card-grid">
            ${promotions.map(p => `<div class="card"><h3>${p.name}</h3><div class="price">Скидка ${p.discount_percent}%</div></div>`).join('')}
        </div>
        ` : ''}
    `;
}

// Услуги
async function renderServices(container) {
    const services = await API.getServices();
    const extra = await API.getExtraServices();
    
    container.innerHTML = `
        <h1 class="section-title">Наши услуги</h1>
        <div class="card-grid">
            ${services.map(s => `
                <div class="card">
                    <h3>${s.name}</h3>
                    <div class="price">от ${s.prices?.[0]?.price || '—'} ₽</div>
                </div>
            `).join('')}
        </div>
        <h2 class="section-title">Дополнительные услуги</h2>
        <div class="card-grid">
            ${extra.map(e => `
                <div class="card">
                    <h3>${e.name}</h3>
                    <div class="price">${e.price} ₽</div>
                </div>
            `).join('')}
        </div>
    `;
}

// Мастера
// Мастера с рейтингом и отзывами
async function renderMasters(container) {
    const masters = await API.getMasters();
    
    container.innerHTML = `
        <h1 class="section-title">Наши мастера</h1>
        <div class="card-grid">
            ${masters.map(m => `
                <div class="card master-card" data-master-id="${m.id}">
                    <div class="master-photo"><i class="fas fa-user-circle"></i></div>
                    <h3>${m.name}</h3>
                    <span class="level-badge">${m.level_name}</span>
                    <div class="rating-display" id="rating-${m.id}">
                        <i class="fas fa-star" style="color: #ffc107;"></i>
                        <span class="rating-value">—</span>
                        <span class="rating-count">(0 отзывов)</span>
                    </div>
                    <button class="btn-outline-small" onclick="showReviews(${m.id}, '${m.name}')">📝 Отзывы</button>
                </div>
            `).join('')}
        </div>
    `;
    
    // Загружаем рейтинги для всех мастеров
    for (const master of masters) {
        try {
            const reviewData = await API.getMasterReviews(master.id);
            const ratingSpan = document.querySelector(`#rating-${master.id} .rating-value`);
            const countSpan = document.querySelector(`#rating-${master.id} .rating-count`);
            if (ratingSpan) {
                if (reviewData.average_rating) {
                    ratingSpan.textContent = reviewData.average_rating;
                    countSpan.textContent = `(${reviewData.total_reviews} ${getDeclension(reviewData.total_reviews, 'отзыв', 'отзыва', 'отзывов')})`;
                } else {
                    ratingSpan.textContent = 'Нет отзывов';
                    countSpan.textContent = '';
                }
            }
        } catch (error) {
            console.error('Ошибка загрузки рейтинга:', error);
        }
    }
}

function getDeclension(number, one, two, five) {
    let n = Math.abs(number);
    n %= 100;
    if (n >= 5 && n <= 20) return five;
    n %= 10;
    if (n === 1) return one;
    if (n >= 2 && n <= 4) return two;
    return five;
}
// Показать отзывы о мастере
window.showReviews = async (masterId, masterName) => {
    try {
        const reviewData = await API.getMasterReviews(masterId);
        
        const modalHtml = `
            <div class="modal" id="reviewsModal">
                <div class="modal-content" style="max-width: 600px; max-height: 80vh; overflow-y: auto;">
                    <h2>📝 Отзывы о ${masterName}</h2>
                    
                    <div style="text-align: center; margin: 20px 0; padding: 15px; background: #fce4ec; border-radius: 15px;">
                        <div style="font-size: 2rem; font-weight: bold; color: #c76e8e;">
                            ${reviewData.average_rating ? '⭐ ' + reviewData.average_rating : 'Нет оценок'}
                        </div>
                        <div style="color: #666;">
                            ${reviewData.total_reviews} ${getDeclension(reviewData.total_reviews, 'отзыв', 'отзыва', 'отзывов')}
                        </div>
                    </div>
                    
                    ${currentUser ? `
                    <div style="margin: 20px 0; padding: 15px; background: #f5f5f5; border-radius: 15px;">
                        <h3>Оставить отзыв</h3>
                        <div class="form-group">
                            <label>Оценка:</label>
                            <div class="rating-input">
                                ${[1,2,3,4,5].map(r => `
                                    <span class="star" data-rating="${r}" style="font-size: 2rem; cursor: pointer; color: #ddd;">★</span>
                                `).join('')}
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Комментарий:</label>
                            <textarea id="reviewComment" rows="3" style="width: 100%; padding: 10px; border-radius: 10px; border: 1px solid #ddd;"></textarea>
                        </div>
                        <button class="btn-primary" onclick="submitReview(${masterId})">Отправить отзыв</button>
                    </div>
                    ` : `
                    <div style="margin: 20px 0; padding: 15px; background: #fff3e0; border-radius: 15px; text-align: center;">
                        <p>Войдите, чтобы оставить отзыв</p>
                        <button class="btn-primary" onclick="closeModal(); showLoginModal()">Войти</button>
                    </div>
                    `}
                    
                    <h3>💬 Все отзывы</h3>
                    <div id="reviewsList">
                        ${reviewData.reviews.length === 0 ? '<p style="text-align: center; color: #999;">Пока нет отзывов. Будьте первым!</p>' : `
                            ${reviewData.reviews.map(r => `
                                <div style="border-bottom: 1px solid #eee; padding: 15px 0;">
                                    <div style="display: flex; justify-content: space-between; align-items: center;">
                                        <div>
                                            <span style="font-weight: bold;">${r.client_name}</span>
                                            <span style="color: #ffc107;">${'★'.repeat(r.rating)}${'☆'.repeat(5-r.rating)}</span>
                                        </div>
                                        <small style="color: #999;">${new Date(r.created_at).toLocaleDateString()}</small>
                                    </div>
                                    <p style="margin-top: 10px; color: #555;">${r.comment || 'Без комментария'}</p>
                                </div>
                            `).join('')}
                        `}
                    </div>
                    
                    <button class="btn-outline" onclick="closeModal()" style="margin-top: 20px;">Закрыть</button>
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', modalHtml);
        
        // Инициализация звездочек для рейтинга
        let selectedRating = 0;
        const stars = document.querySelectorAll('.star');
        stars.forEach(star => {
            star.addEventListener('click', () => {
                selectedRating = parseInt(star.dataset.rating);
                stars.forEach((s, i) => {
                    if (i < selectedRating) {
                        s.style.color = '#ffc107';
                    } else {
                        s.style.color = '#ddd';
                    }
                });
            });
        });
        
        window.currentMasterId = masterId;
        window.currentSelectedRating = () => selectedRating;
        
    } catch (error) {
        alert('Ошибка загрузки отзывов: ' + error.message);
    }
    
};

// Отправить отзыв
// Отправить отзыв
window.submitReview = async (masterId) => {
    const stars = document.querySelectorAll('.star');
    let rating = 0;
    stars.forEach((star, index) => {
        if (star.style.color === 'rgb(255, 193, 7)' || star.style.color === '#ffc107') {
            rating = index + 1;
        }
    });
    const comment = document.getElementById('reviewComment')?.value || '';
    
    if (rating === 0) {
        alert('Пожалуйста, поставьте оценку (1-5 звезд)');
        return;
    }
    
    try {
        const response = await fetch(`/api/masters/${masterId}/reviews`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ rating, comment })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            alert('✅ ' + data.message);
            // Обновляем модальное окно с отзывами
            closeModal();
            showReviews(masterId, document.querySelector(`.master-card[data-master-id="${masterId}"] h3`)?.innerText || 'мастере');
        } else {
            alert('❌ ' + data.error);
        }
    } catch (error) {
        alert('❌ Ошибка: ' + error.message);
    }
};

// Запись с визуальным отображением свободных слотов
async function renderBooking(container) {
    if (!currentUser) {
        container.innerHTML = `
            <div class="card" style="text-align:center;">
                <h3>Для записи необходимо войти в аккаунт</h3>
                <button class="btn-primary" onclick="showLoginModal()">Войти</button>
                <button class="btn-outline" onclick="showRegisterModal()">Зарегистрироваться</button>
            </div>
        `;
        return;
    }
    
    const masters = await API.getMasters();
    const services = await API.getServices();
    const extra = await API.getExtraServices();
    
    container.innerHTML = `
        <h1 class="section-title">📅 Запись на процедуру</h1>
        <div class="card">
            <form id="bookingForm">
                <div class="form-group">
                    <label>Выберите мастера</label>
                    <select id="masterId" required>
                        <option value="">Выбор мастера</option>
                        ${masters.map(m => `<option value="${m.id}" data-level="${m.level_id}" data-level-name="${m.level_name}">${m.name} (${m.level_name})</option>`).join('')}
                    </select>
                </div>
                <div class="form-group">
                    <label>Выберите услугу</label>
                    <select id="serviceId" required>
                        <option value="">Выбор услугу</option>
                        ${services.map(s => `<option value="${s.id}" data-name="${s.name}">${s.name}</option>`).join('')}
                    </select>
                </div>
                
                <!-- Блок с ценой услуги -->
                <div id="priceBlock" style="display:none; background: linear-gradient(135deg, #fce4ec, #fff0f3); padding: 20px; border-radius: 20px; margin: 20px 0; text-align: center; border: 1px solid #f5a3b7;">
                    <div style="font-size: 0.85rem; color: #c76e8e;">СТОИМОСТЬ УСЛУГИ</div>
                    <div style="font-size: 2.5rem; font-weight: 800; color: #c76e8e; margin: 10px 0;" id="priceAmount">— ₽</div>
                    <div style="font-size: 0.8rem; color: #a07382;" id="priceDetail"></div>
                </div>
                
                <div class="form-group">
                    <label>Дополнительные услуги</label>
                    <select id="extraIds" multiple size="3">
                        ${extra.map(e => `<option value="${e.id}" data-price="${e.price}" data-name="${e.name}">${e.name} (+${e.price}₽)</option>`).join('')}
                    </select>
                    <small>📌 Для выбора нескольких зажмите Ctrl</small>
                </div>
                
                <!-- Блок с итогом -->
                <div id="totalBlock" style="display:none; margin-top: 20px; padding: 15px; background: #f8f9fa; border-radius: 15px; border-left: 4px solid #c76e8e;">
                    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
                        <div>
                            <span style="color: #666; font-size: 0.85rem;">Услуга:</span>
                            <span style="font-weight: bold; color: #c76e8e; font-size: 1.1rem;" id="totalServicePrice">0 ₽</span>
                        </div>
                        <div>
                            <span style="color: #666; font-size: 0.85rem;">➕ Доп. услуги:</span>
                            <span style="font-weight: bold; color: #c76e8e; font-size: 1.1rem;" id="totalExtraPrice">0 ₽</span>
                        </div>
                        <div style="background: #c76e8e15; padding: 5px 15px; border-radius: 25px;">
                            <span style="color: #666; font-size: 0.85rem;">ИТОГО:</span>
                            <span style="font-size: 1.4rem; font-weight: 800; color: #c76e8e; margin-left: 8px;" id="totalFinalPrice">0 ₽</span>
                        </div>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Выберите дату</label>
                    <input type="date" id="date" required min="${new Date().toISOString().split('T')[0]}">
                </div>
                
                <!-- Визуальная сетка времени -->
                <div class="form-group">
                    <label>Выберите время</label>
                    <div id="timeSlotsContainer" style="margin-top: 10px;">
                        <div style="text-align: center; padding: 20px; color: #999;">Сначала выберите мастера и дату</div>
                    </div>
                    <input type="hidden" id="selectedTime" required>
                </div>
                
                <button type="submit" class="btn-primary" style="width: 100%; padding: 15px; font-size: 1.1rem;">Записаться</button>
            </form>
        </div>
        <div id="bookingMsg"></div>
    `;
    
    const masterSelect = document.getElementById('masterId');
    const serviceSelect = document.getElementById('serviceId');
    const extraSelect = document.getElementById('extraIds');
    const dateInput = document.getElementById('date');
    const timeSlotsContainer = document.getElementById('timeSlotsContainer');
    const selectedTimeInput = document.getElementById('selectedTime');
    const priceBlock = document.getElementById('priceBlock');
    const priceAmount = document.getElementById('priceAmount');
    const priceDetail = document.getElementById('priceDetail');
    const totalBlock = document.getElementById('totalBlock');
    const totalServicePrice = document.getElementById('totalServicePrice');
    const totalExtraPrice = document.getElementById('totalExtraPrice');
    const totalFinalPrice = document.getElementById('totalFinalPrice');
    
    let currentPrice = 0;
    let currentMasterName = '';
    let currentServiceName = '';
    let currentLevelName = '';
    let selectedSlot = null;
    
    // Функция обновления итога
    function updateTotalDisplay() {
        let extraTotal = 0;
        const selectedExtras = Array.from(extraSelect.selectedOptions);
        
        for (let i = 0; i < selectedExtras.length; i++) {
            let extraPrice = parseFloat(selectedExtras[i].dataset.price);
            if (!isNaN(extraPrice)) {
                extraTotal = extraTotal + extraPrice;
            }
        }
        
        let servicePrice = parseFloat(currentPrice);
        if (isNaN(servicePrice)) servicePrice = 0;
        
        let finalTotal = servicePrice + extraTotal;
        
        totalServicePrice.textContent = servicePrice.toFixed(0) + ' ₽';
        totalExtraPrice.textContent = extraTotal.toFixed(0) + ' ₽';
        totalFinalPrice.textContent = finalTotal.toFixed(0) + ' ₽';
        
        totalFinalPrice.style.transform = 'scale(1.05)';
        setTimeout(() => { totalFinalPrice.style.transform = 'scale(1)'; }, 150);
    }
    
    // Функция обновления цены
    async function updatePrice() {
        const masterId = masterSelect.value;
        const serviceId = serviceSelect.value;
        
        if (!masterId || !serviceId) {
            priceBlock.style.display = 'none';
            totalBlock.style.display = 'none';
            return;
        }
        
        const selectedMaster = masterSelect.options[masterSelect.selectedIndex];
        const levelId = parseInt(selectedMaster.dataset.level);
        currentMasterName = selectedMaster.textContent.split(' (')[0];
        currentLevelName = selectedMaster.dataset.levelName || '';
        
        const selectedService = serviceSelect.options[serviceSelect.selectedIndex];
        currentServiceName = selectedService.dataset.name;
        
        try {
            const priceData = await API.getPrice(serviceId, levelId);
            currentPrice = parseFloat(priceData.price);
            
            priceAmount.textContent = currentPrice.toFixed(0) + ' ₽';
            priceDetail.innerHTML = `${currentServiceName}<br>Мастер: ${currentMasterName} (${currentLevelName})`;
            priceBlock.style.display = 'block';
            
            updateTotalDisplay();
            totalBlock.style.display = 'block';
        } catch (error) {
            console.error('Ошибка получения цены:', error);
            priceAmount.textContent = '— ₽';
            priceDetail.innerHTML = 'Цена временно недоступна';
            priceBlock.style.display = 'block';
        }
    }
    
    // Обновление итога при изменении доп. услуг
    function updateTotal() {
        if (currentPrice > 0) {
            updateTotalDisplay();
            totalBlock.style.display = 'block';
        }
    }
    
    // Функция отображения сетки времени (ВИЗУАЛЬНАЯ)
    async function loadTimeSlots() {
        const masterId = masterSelect.value;
        const date = dateInput.value;
        
        if (!masterId || !date) {
            timeSlotsContainer.innerHTML = '<div style="text-align: center; padding: 20px; color: #999;">Сначала выберите мастера и дату</div>';
            return;
        }
        
        timeSlotsContainer.innerHTML = '<div style="text-align: center; padding: 20px;">⏳ Загрузка свободного времени...</div>';
        selectedSlot = null;
        selectedTimeInput.value = '';
        
        try {
            const slots = await API.getMasterAvailableSlots(masterId, date);
            
            if (slots.length === 0) {
                timeSlotsContainer.innerHTML = `
                    <div style="text-align: center; padding: 30px; background: #ffebee; border-radius: 15px; color: #c62828;">
                        К сожалению, на эту дату нет свободного времени
                    </div>
                `;
                return;
            }
            
            // Все возможные часы для отображения
            const allHours = ['09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00'];
            
            let slotsHtml = `
                <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-top: 10px;">
            `;
            
            for (const hour of allHours) {
                const isAvailable = slots.includes(hour);
                if (isAvailable) {
                    slotsHtml += `
                        <div class="time-slot available" data-time="${hour}" style="
                            background: linear-gradient(135deg, #60ff68, #60ff68);
                            color: white;
                            padding: 12px;
                            border-radius: 12px;
                            text-align: center;
                            cursor: pointer;
                            font-weight: bold;
                            transition: all 0.3s ease;
                            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
                        " onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
                            🟢 ${hour}
                        </div>
                    `;
                } else {
                    slotsHtml += `
                        <div class="time-slot unavailable" style="
                            background: #e0e0e0;
                            color: #999;
                            padding: 12px;
                            border-radius: 12px;
                            text-align: center;
                            cursor: not-allowed;
                            font-weight: normal;
                        ">
                            🔴 ${hour}
                        </div>
                    `;
                }
            }
            
            slotsHtml += `</div>`;
            timeSlotsContainer.innerHTML = slotsHtml;
            
            // Добавляем обработчики для свободных слотов
            document.querySelectorAll('.time-slot.available').forEach(slot => {
                slot.addEventListener('click', () => {
                    // Убираем выделение с предыдущего
                    document.querySelectorAll('.time-slot.available').forEach(s => {
                        s.style.background = 'linear-gradient(135deg, #478049, #478049)';
                        s.style.border = 'none';
                    });
                    // Выделяем выбранный
                    slot.style.background = 'linear-gradient(135deg, #5a4c37, #5a4c37)';
                    slot.style.border = '2px solid #fff';
                    selectedSlot = slot.dataset.time;
                    selectedTimeInput.value = selectedSlot;
                });
            });
            
        } catch (error) {
            console.error('Ошибка загрузки слотов:', error);
            timeSlotsContainer.innerHTML = `
                <div style="text-align: center; padding: 20px; background: #ffebee; border-radius: 15px; color: #c62828;">
                    ❌ Ошибка загрузки времени. Попробуйте позже.
                </div>
            `;
        }
    }
    
    // Обработчики событий
    masterSelect.onchange = () => {
        updatePrice();
        if (dateInput.value) loadTimeSlots();
    };
    serviceSelect.onchange = updatePrice;
    extraSelect.onchange = updateTotal;
    dateInput.onchange = loadTimeSlots;
    
    // Отправка формы
    document.getElementById('bookingForm').onsubmit = async (e) => {
        e.preventDefault();
        
        if (!masterSelect.value || !serviceSelect.value || !dateInput.value || !selectedSlot) {
            document.getElementById('bookingMsg').innerHTML = '<div class="card" style="color:red; text-align:center;">❌ Заполните все поля и выберите время!</div>';
            setTimeout(() => {
                document.getElementById('bookingMsg').innerHTML = '';
            }, 3000);
            return;
        }
        
        const data = {
            master_id: parseInt(masterSelect.value),
            service_id: parseInt(serviceSelect.value),
            extra_service_ids: Array.from(extraSelect.selectedOptions).map(o => parseInt(o.value)),
            appointment_date: dateInput.value,
            appointment_time: selectedSlot
        };
        
        try {
            await API.createAppointment(data);
            document.getElementById('bookingMsg').innerHTML = '<div class="card" style="color:green; text-align:center;">✅ Запись успешно создана! Ждем вас ❤️</div>';
            document.getElementById('bookingForm').reset();
            priceBlock.style.display = 'none';
            totalBlock.style.display = 'none';
            timeSlotsContainer.innerHTML = '<div style="text-align: center; padding: 20px; color: #999;">Сначала выберите мастера и дату</div>';
            selectedSlot = null;
            selectedTimeInput.value = '';
            setTimeout(() => {
                document.getElementById('bookingMsg').innerHTML = '';
            }, 5000);
        } catch (err) {
            document.getElementById('bookingMsg').innerHTML = `<div class="card" style="color:red; text-align:center;">❌ ${err.message}</div>`;
            setTimeout(() => {
                document.getElementById('bookingMsg').innerHTML = '';
            }, 5000);
        }
    };
}

// Акции с отображением дат и времени
async function renderPromotions(container) {
    const promotions = await API.getPromotions();
    
    if (!promotions.length) {
        container.innerHTML = '<div class="card"><h3>На данный момент акций нет</h3></div>';
        return;
    }
    
    container.innerHTML = `
        <h1 class="section-title">Акции и скидки</h1>
        <div class="card-grid">
            ${promotions.map(p => {
                // Определяем иконку в зависимости от типа акции
                let icon = '🎉';
                let bgColor = 'linear-gradient(135deg, #fff0f3, #ffe4ec)';
                
                if (p.promotion_type === 'new_client') {
                    icon = '🆕';
                    bgColor = 'linear-gradient(135deg, #e8f5e9, #c8e6c9)';
                } else if (p.promotion_type === 'happy_hours') {
                    icon = '⏰';
                    bgColor = 'linear-gradient(135deg, #fff3e0, #ffe0b2)';
                } else if (p.promotion_type === 'seasonal') {
                    icon = '🌸';
                    bgColor = 'linear-gradient(135deg, #fce4ec, #f8bbd0)';
                }
                
                return `
                    <div class="card" style="background: ${bgColor};">
                        <div style="font-size: 3rem; text-align: center;">${icon}</div>
                        <h3 style="text-align: center; margin: 10px 0;">${p.name}</h3>
                        <div class="price" style="text-align: center; font-size: 2rem;">-${p.discount_percent}%</div>
                        <div style="text-align: center; margin: 15px 0;">
                            <span style="background: rgba(0,0,0,0.05); padding: 5px 12px; border-radius: 20px; font-size: 0.85rem;">
                                ${p.description || p.name}
                            </span>
                        </div>
                        
                        <!-- Условия акции -->
                        <div style="margin-top: 15px; padding: 10px; background: rgba(255,255,255,0.6); border-radius: 12px; font-size: 0.85rem;">
                            <div style="display: flex; align-items: center; gap: 8px; justify-content: center;">
                                <span>📌</span>
                                <span>${p.conditions || 'Действует на все услуги'}</span>
                            </div>
                        </div>
                        
                        <!-- Дополнительная информация в зависимости от типа -->
                        ${p.promotion_type === 'happy_hours' ? `
                            <div style="margin-top: 10px; text-align: center; font-size: 0.8rem; color: #e65100;">
                                ⭐ Только в утренние часы!
                            </div>
                        ` : ''}
                        
                        ${p.promotion_type === 'new_client' ? `
                            <div style="margin-top: 10px; text-align: center; font-size: 0.8rem; color: #2e7d32;">
                                🎁 Для тех, кто записывается впервые
                            </div>
                        ` : ''}
                        
                        ${p.promotion_type === 'seasonal' ? `
                            <div style="margin-top: 10px; text-align: center; font-size: 0.8rem; color: #c76e8e;">
                                🌸 Ограниченное предложение!
                            </div>
                        ` : ''}
                    </div>
                `;
            }).join('')}
        </div>
        
        <!-- Дополнительная информация о применении акций -->
        <div class="card" style="margin-top: 30px; background: #f5f5f5;">
            <h3 style="text-align: center;">ℹ️ Как работают акции</h3>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 15px; margin-top: 15px;">
                <div style="text-align: center;">
                    <div style="font-size: 2rem;">🆕</div>
                    <div style="font-weight: bold;">Новым клиентам</div>
                    <div style="font-size: 0.8rem; color: #666;">Применяется автоматически при первой записи</div>
                </div>
                <div style="text-align: center;">
                    <div style="font-size: 2rem;">⏰</div>
                    <div style="font-weight: bold;">Счастливые часы</div>
                    <div style="font-size: 0.8rem; color: #666;">Действует с 9:00 до 12:00</div>
                </div>
                <div style="text-align: center;">
                    <div style="font-size: 2rem;">🌸</div>
                    <div style="font-weight: bold;">Сезонные акции</div>
                    <div style="font-size: 0.8rem; color: #666;">Действуют в указанные даты</div>
                </div>
            </div>
            <div style="text-align: center; margin-top: 15px; padding: 10px; background: #ffebee; border-radius: 10px; font-size: 0.85rem;">
                 Акции не суммируются. Применяется максимальная доступная скидка.
            </div>
        </div>
    `;
}


// Мои записи (личный кабинет)
// Мои записи (личный кабинет) с ценой и красивой датой
// Мои записи (личный кабинет)
// Мои записи (исправленная дата и стоимость)
async function renderMyAppointments(container) {
    if (!currentUser) {
        container.innerHTML = `
            <div class="card" style="text-align:center;">
                <h3>🔐 Войдите, чтобы увидеть свои записи</h3>
                <button class="btn-primary" onclick="showLoginModal()">Войти</button>
                <button class="btn-outline" onclick="showRegisterModal()">Зарегистрироваться</button>
            </div>
        `;
        return;
    }
    
    container.innerHTML = '<div style="text-align:center;padding:50px;">⏳ Загрузка ваших записей...</div>';
    
    try {
        const appointments = await API.getMyAppointments();
        
        if (appointments.length === 0) {
            container.innerHTML = `
                <div class="card" style="text-align:center;">
                    <h2>📋 Мои записи</h2>
                    <p>У вас пока нет записей</p>
                    <button class="btn-primary" onclick="showPage('booking')">📅 Записаться</button>
                </div>
            `;
            return;
        }
        
        container.innerHTML = `
            <h1 class="section-title">📋 Мои записи</h1>
            <div class="table-container">
                <table style="width: 100%;">
                    <thead>
                        <tr>
                            <th>Дата</th>
                            <th>Время</th>
                            <th>Мастер</th>
                            <th>Услуга</th>
                            <th>Дополнительно</th>
                            <th>Исходная цена</th>
                            <th>Скидка</th>
                            <th>Итого</th>
                            <th>Статус</th>
                            <th>Действие</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${appointments.map(app => {
                            // ========== ФОРМАТИРУЕМ ДАТУ ==========
                            let formattedDate = '';
                            if (app.appointment_date) {
                                if (app.appointment_date.includes('-') && !app.appointment_date.includes('T')) {
                                    const parts = app.appointment_date.split('-');
                                    formattedDate = `${parts[2].padStart(2, '0')}.${parts[1].padStart(2, '0')}.${parts[0]}`;
                                }
                                else if (app.appointment_date.includes('T')) {
                                    const dateObj = new Date(app.appointment_date);
                                    const day = dateObj.getDate().toString().padStart(2, '0');
                                    const month = (dateObj.getMonth() + 1).toString().padStart(2, '0');
                                    const year = dateObj.getFullYear();
                                    formattedDate = `${day}.${month}.${year}`;
                                }
                                else {
                                    formattedDate = app.appointment_date;
                                }
                            }
                            
                            // ========== ФОРМАТИРУЕМ ВРЕМЯ ==========
                            let formattedTime = '';
                            if (app.appointment_time) {
                                if (app.appointment_time.includes(':')) {
                                    formattedTime = app.appointment_time.substring(0, 5);
                                }
                                else if (typeof app.appointment_time === 'string' && app.appointment_time.includes('T')) {
                                    const timeObj = new Date(app.appointment_time);
                                    formattedTime = timeObj.toTimeString().substring(0, 5);
                                }
                                else {
                                    formattedTime = app.appointment_time;
                                }
                            }
                            
                            // ========== РАСЧЕТ ЦЕНЫ СО СКИДКОЙ ==========
                            let originalPrice = 0;
                            let discountPercent = app.discount_applied || 0;
                            let finalPrice = app.total_price || 0;
                            
                            // Если есть скидка, рассчитываем исходную цену
                            if (discountPercent > 0 && finalPrice > 0) {
                                originalPrice = finalPrice / (1 - discountPercent / 100);
                            } else if (finalPrice > 0) {
                                originalPrice = finalPrice;
                            }
                            
                            // Форматируем отображение
                            let originalPriceHtml = '—';
                            let discountHtml = '—';
                            let finalPriceHtml = '—';
                            
                            if (originalPrice > 0) {
                                originalPriceHtml = `${Math.round(originalPrice).toLocaleString()} ₽`;
                            }
                            
                            if (discountPercent > 0) {
                                discountHtml = `<span style="color: #4caf50; font-weight: bold;">-${discountPercent}%</span>`;
                            }
                            
                            if (finalPrice > 0) {
                                finalPriceHtml = `<span style="font-weight: bold; color: #c76e8e;">${Math.round(finalPrice).toLocaleString()} ₽</span>`;
                            }
                            
                            // Статус с эмодзи
                            let statusHtml = '';
                            if (app.status === 'Запланирована') statusHtml = '<span class="status-planned">🟢 Запланирована</span>';
                            else if (app.status === 'Выполнена') statusHtml = '<span class="status-completed">✅ Выполнена</span>';
                            else statusHtml = '<span class="status-canceled">❌ Отменена</span>';
                            
                            // ========== ДОП. УСЛУГИ ДРУГ ПОД ДРУГОМ ==========
                            let extraServicesHtml = '';
                            if (app.extra_services && app.extra_services !== '—') {
                                const services = app.extra_services.split(',');
                                extraServicesHtml = services.map(service => 
                                    `<div style="margin: 3px 0; font-size: 0.8rem;">${service.trim()}</div>`
                                ).join('');
                            } else {
                                extraServicesHtml = '—';
                            }
                            
                            return `
                                <tr>
                                    <td><strong>${formattedDate}</strong></td>
                                    <td>${formattedTime}</td>
                                    <td>${app.master_name || '—'}</td>
                                    <td>${app.service_name || '—'}</td>
                                    <td style="max-width: 200px; padding: 8px;">${extraServicesHtml}</td>
                                    <td style="text-decoration: ${discountPercent > 0 ? 'line-through' : 'none'}; color: ${discountPercent > 0 ? '#999' : '#333'};">${originalPriceHtml}</td>
                                    <td>${discountHtml}</td>
                                    <td>${finalPriceHtml}</td>
                                    <td>${statusHtml}</td>
                                    <td>
                                        ${app.status === 'Запланирована' ? 
                                            `<button onclick="cancelAppointment(${app.id})" class="btn-outline-small" style="background:#ffebee; color:#c62828; cursor:pointer;">❌ Отменить</button>` : 
                                            '—'
                                        }
                                    </td>
                                </tr>
                            `;
                        }).join('')}
                    </tbody>
                </table>
            </div>
        `;
    } catch (error) {
        console.error('Ошибка:', error);
        container.innerHTML = `<div class="card"><h3>❌ Ошибка загрузки: ${error.message}</h3></div>`;
    }
}
// Глобальная функция для отмены записи
window.cancelAppointment = async (id) => {
    if (confirm('Вы уверены, что хотите отменить эту запись?')) {
        try {
            await API.cancelAppointment(id);
            alert('✅ Запись успешно отменена');
            showPage('myAppointments');
        } catch (error) {
            alert('❌ Ошибка: ' + error.message);
        }
    }
};
// Админ-панель
// Админ-панель (полная версия)
// ==================== ФИЛЬТРАЦИЯ ЗАПИСЕЙ (ПО ДАТЕ И МАСТЕРУ) ====================

window.filterAppointments = async () => {
    const date = document.getElementById('filterDate').value;
    const masterId = document.getElementById('filterMaster').value;
    
    let url = '/api/admin/appointments?';
    const params = [];
    
    if (date) {
        params.push(`date=${date}`);
    }
    if (masterId) {
        params.push(`masterId=${masterId}`);
    }
    
    url += params.join('&');
    
    if (!date && !masterId) {
        alert('Выберите дату или мастера для фильтрации');
        return;
    }
    
    try {
        const response = await fetch(url, {
            headers: { 'Authorization': `Bearer ${token}` }
        });
        const appointments = await response.json();
        
        const tbody = document.getElementById('appointmentsTableBody');
        if (tbody) {
            if (appointments.length === 0) {
                tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;">❌ Записи не найдены</td></tr>';
            } else {
                tbody.innerHTML = appointments.map(a => {
                    let formattedDate = a.appointment_date;
                    if (formattedDate && formattedDate.includes('T')) formattedDate = formattedDate.split('T')[0];
                    let formattedTime = a.appointment_time;
                    if (formattedTime && formattedTime.includes(':')) formattedTime = formattedTime.substring(0, 5);
                    return `
                        <tr>
                            <td>${a.client_name || '—'}</td>
                            <td>${a.master_name || '—'}</td>
                            <td>${formattedDate || '—'}</td>
                            <td>${formattedTime || '—'}</td>
                            <td>${a.service_name || '—'}</td>
                            <td>
                                <select class="status-select" data-id="${a.id}">
                                    <option ${a.status === 'Запланирована' ? 'selected' : ''}>Запланирована</option>
                                    <option ${a.status === 'Выполнена' ? 'selected' : ''}>Выполнена</option>
                                    <option ${a.status === 'Отменена' ? 'selected' : ''}>Отменена</option>
                                </select>
                            </td>
                            <td><button class="btn-save" onclick="updateAppointmentStatus(${a.id})">💾 Сохранить</button></td>
                        </tr>
                    `;
                }).join('');
            }
        }
    } catch (error) {
        alert('Ошибка: ' + error.message);
    }
};

window.showAllAppointments = async () => {
    try {
        const response = await fetch('/api/admin/appointments', {
            headers: { 'Authorization': `Bearer ${token}` }
        });
        const appointments = await response.json();
        
        const tbody = document.getElementById('appointmentsTableBody');
        if (tbody) {
            tbody.innerHTML = appointments.map(a => {
                let formattedDate = a.appointment_date;
                if (formattedDate && formattedDate.includes('T')) formattedDate = formattedDate.split('T')[0];
                let formattedTime = a.appointment_time;
                if (formattedTime && formattedTime.includes(':')) formattedTime = formattedTime.substring(0, 5);
                return `
                    <tr>
                        <td>${a.client_name || '—'}</td>
                        <td>${a.master_name || '—'}</td>
                        <td>${formattedDate || '—'}</td>
                        <td>${formattedTime || '—'}</td>
                        <td>${a.service_name || '—'}</td>
                        <td>
                            <select class="status-select" data-id="${a.id}">
                                <option ${a.status === 'Запланирована' ? 'selected' : ''}>Запланирована</option>
                                <option ${a.status === 'Выполнена' ? 'selected' : ''}>Выполнена</option>
                                <option ${a.status === 'Отменена' ? 'selected' : ''}>Отменена</option>
                            </select>
                        </td>
                        <td><button class="btn-save" onclick="updateAppointmentStatus(${a.id})">💾 Сохранить</button></td>
                    </tr>
                `;
            }).join('');
        }
        
        // Очищаем поля фильтра
        const filterDate = document.getElementById('filterDate');
        const filterMaster = document.getElementById('filterMaster');
        if (filterDate) filterDate.value = '';
        if (filterMaster) filterMaster.value = '';
        
    } catch (error) {
        alert('Ошибка: ' + error.message);
    }
};
// ==================== ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ====================

function getPromotionTypeName(type) {
    switch(type) {
        case 'new_client': return '🎁 Новым клиентам';
        case 'happy_hours': return '⏰ Счастливые часы';
        case 'seasonal': return '🌸 Сезонная';
        default: return '📌 Обычная';
    }
}

function getPromotionConditions(p) {
    if (p.promotion_type === 'happy_hours' && p.start_time && p.end_time) {
        return `${p.start_time.substring(0,5)} - ${p.end_time.substring(0,5)}`;
    }
    if (p.promotion_type === 'seasonal' && p.start_date && p.end_date) {
        return `${formatDate(p.start_date)} - ${formatDate(p.end_date)}`;
    }
    if (p.promotion_type === 'new_client') {
        return 'Первая запись';
    }
    return 'На все услуги';
}

function formatDate(dateStr) {
    if (!dateStr) return '—';
    const parts = dateStr.split('-');
    if (parts.length === 3) {
        return `${parts[2]}.${parts[1]}.${parts[0]}`;
    }
    return dateStr;
}

function togglePromotionFields() {
    const type = document.getElementById('promoType').value;
    const happyFields = document.getElementById('happyHoursFields');
    const seasonalFields = document.getElementById('seasonalFields');
    
    happyFields.style.display = type === 'happy_hours' ? 'flex' : 'none';
    seasonalFields.style.display = type === 'seasonal' ? 'flex' : 'none';
}

// ==================== УПРАВЛЕНИЕ МАСТЕРАМИ ====================

window.saveMasterLevel = async (id) => {
    const select = document.querySelector(`.level-select[data-id="${id}"]`);
    const level_id = parseInt(select.value);
    try {
        const response = await fetch(`/api/admin/masters/${id}/level`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
            body: JSON.stringify({ level_id })
        });
        if (response.ok) {
            alert('✅ Уровень мастера обновлен');
            showPage('admin');
        } else {
            alert('❌ Ошибка');
        }
    } catch (error) {
        alert('Ошибка: ' + error.message);
    }
};

window.deleteMaster = async (id) => {
    if (confirm('Вы уверены, что хотите удалить этого мастера? Удалятся все его записи!')) {
        try {
            const response = await fetch(`/api/admin/masters/${id}`, {
                method: 'DELETE',
                headers: { 'Authorization': `Bearer ${token}` }
            });
            if (response.ok) {
                alert('Мастер удален');
                showPage('admin');
            } else {
                const error = await response.json();
                alert('Ошибка: ' + (error.error || 'Неизвестная ошибка'));
            }
        } catch (error) {
            alert('Ошибка: ' + error.message);
        }
    }
};

window.addMaster = async () => {
    const name = document.getElementById('newMasterName').value;
    const phone = document.getElementById('newMasterPhone').value;
    const level_id = parseInt(document.getElementById('newMasterLevel').value);
    
    if (!name || !phone) {
        alert('Заполните имя и телефон');
        return;
    }
    
    try {
        const response = await fetch('/api/admin/masters', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
            body: JSON.stringify({ name, phone, level_id })
        });
        if (response.ok) {
            alert('✅ Мастер добавлен');
            document.getElementById('newMasterName').value = '';
            document.getElementById('newMasterPhone').value = '';
            showPage('admin');
        } else {
            alert('❌ Ошибка');
        }
    } catch (error) {
        alert('Ошибка: ' + error.message);
    }
};

// ==================== УПРАВЛЕНИЕ АКЦИЯМИ ====================

window.togglePromotion = async (id, newStatus) => {
    try {
        const response = await fetch(`/api/admin/promotions/${id}/toggle`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
            body: JSON.stringify({ is_active: newStatus })
        });
        if (response.ok) {
            alert('✅ Статус акции обновлен');
            showPage('admin');
        } else {
            alert('❌ Ошибка');
        }
    } catch (error) {
        alert('Ошибка: ' + error.message);
    }
};

window.deletePromotion = async (id) => {
    if (confirm('Удалить акцию?')) {
        try {
            const response = await fetch(`/api/admin/promotions/${id}`, {
                method: 'DELETE',
                headers: { 'Authorization': `Bearer ${token}` }
            });
            if (response.ok) {
                alert('✅ Акция удалена');
                showPage('admin');
            } else {
                alert('❌ Ошибка');
            }
        } catch (error) {
            alert('Ошибка: ' + error.message);
        }
    }
};

// Добавление акции через форму
document.addEventListener('submit', async (e) => {
    if (e.target && e.target.id === 'addPromotionForm') {
        e.preventDefault();
        
        const name = document.getElementById('promoName').value;
        const discount_percent = parseInt(document.getElementById('promoDiscount').value);
        const promotion_type = document.getElementById('promoType').value;
        
        let body = { name, discount_percent, promotion_type };
        
        if (promotion_type === 'happy_hours') {
            body.start_time = document.getElementById('promoStartTime').value;
            body.end_time = document.getElementById('promoEndTime').value;
        }
        
        if (promotion_type === 'seasonal') {
            body.start_date = document.getElementById('promoStartDate').value;
            body.end_date = document.getElementById('promoEndDate').value;
        }
        
        if (!name || !discount_percent) {
            alert('Заполните название и скидку');
            return;
        }
        
        try {
            const response = await fetch('/api/admin/promotions', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
                body: JSON.stringify(body)
            });
            if (response.ok) {
                alert('✅ Акция добавлена');
                document.getElementById('addPromotionForm').reset();
                togglePromotionFields();
                showPage('admin');
            } else {
                const error = await response.json();
                alert('❌ Ошибка: ' + (error.error || 'Неизвестная ошибка'));
            }
        } catch (error) {
            alert('Ошибка: ' + error.message);
        }
    }
});

// ==================== УПРАВЛЕНИЕ ЗАПИСЯМИ ====================

window.updateAppointmentStatus = async (id) => {
    const select = document.querySelector(`.status-select[data-id="${id}"]`);
    const status = select.value;
    try {
        const response = await fetch(`/api/admin/appointments/${id}/status`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
            body: JSON.stringify({ status })
        });
        if (response.ok) {
            alert('✅ Статус обновлен');
            showPage('admin');
        } else {
            alert('❌ Ошибка');
        }
    } catch (error) {
        alert('Ошибка: ' + error.message);
    }
};

// Модальные окна
function showLoginModal() {
    const html = `
        <div class="modal" id="loginModal">
            <div class="modal-content">
                <h2>Вход в аккаунт</h2>
                <form id="loginForm">
                    <div class="form-group"><input type="text" id="loginInput" placeholder="Логин" required></div>
                    <div class="form-group"><input type="password" id="passwordInput" placeholder="Пароль" required></div>
                    <button type="submit" class="btn-primary">Войти</button>
                    <button type="button" class="btn-outline" onclick="closeModal()">Отмена</button>
                </form>
            </div>
        </div>
    `;
    document.body.insertAdjacentHTML('beforeend', html);
    
    document.getElementById('loginForm').onsubmit = async (e) => {
        e.preventDefault();
        try {
            await API.login(loginInput.value, passwordInput.value);
            updateUI();
            closeModal();
            showPage('index');
        } catch (err) {
            alert('Ошибка: ' + err.message);
        }
    };
}

function showRegisterModal() {
    const html = `
        <div class="modal" id="registerModal">
            <div class="modal-content">
                <h2>Регистрация</h2>
                <form id="registerForm">
                    <div class="form-group"><input type="text" id="regLogin" placeholder="Логин" required></div>
                    <div class="form-group"><input type="password" id="regPassword" placeholder="Пароль" required></div>
                    <div class="form-group"><input type="text" id="regName" placeholder="Ваше имя" required></div>
                    <div class="form-group"><input type="tel" id="regPhone" placeholder="Телефон" required></div>
                    <button type="submit" class="btn-primary">Зарегистрироваться</button>
                    <button type="button" class="btn-outline" onclick="closeModal()">Отмена</button>
                </form>
            </div>
        </div>
    `;
    document.body.insertAdjacentHTML('beforeend', html);
    
    document.getElementById('registerForm').onsubmit = async (e) => {
        e.preventDefault();
        try {
            await API.register({ login: regLogin.value, password: regPassword.value, name: regName.value, phone: regPhone.value });
            alert('Регистрация успешна! Теперь войдите.');
            closeModal();
            showLoginModal();
        } catch (err) {
            alert('Ошибка: ' + err.message);
        }
    };
}

function closeModal() {
    const modal = document.querySelector('.modal');
    if (modal) modal.remove();
}

function logout() {
    API.logout();
    updateUI();
    showPage('index');
}

// Глобальные функции
window.showPage = showPage;
window.showLoginModal = showLoginModal;
window.showRegisterModal = showRegisterModal;
window.closeModal = closeModal;
window.logout = logout;

// ==================== УПРАВЛЕНИЕ УСЛУГАМИ ====================

window.addService = async () => {
    const name = document.getElementById('newServiceName').value;
    const description = document.getElementById('newServiceDesc').value;
    const duration_minutes = parseInt(document.getElementById('newServiceDuration').value);
    
    if (!name) {
        alert('Введите название услуги');
        return;
    }
    
    try {
        await API.addService({ name, description, duration_minutes });
        alert('✅ Услуга добавлена');
        showPage('admin');
    } catch (error) {
        alert('Ошибка: ' + error.message);
    }
};

window.editService = async (id) => {
    const newName = prompt('Введите новое название услуги:');
    if (newName) {
        try {
            await API.updateService(id, { name: newName });
            alert('✅ Услуга обновлена');
            showPage('admin');
        } catch (error) {
            alert('Ошибка: ' + error.message);
        }
    }
};

window.deleteService = async (id) => {
    if (confirm('Удалить услугу? Это также удалит связанные цены.')) {
        try {
            await API.deleteService(id);
            alert('✅ Услуга удалена');
            showPage('admin');
        } catch (error) {
            alert('Ошибка: ' + error.message);
        }
    }
};

// ==================== УПРАВЛЕНИЕ ЦЕНАМИ ====================

window.updatePrice = async (id) => {
    const priceInput = document.getElementById(`price_${id}`);
    const price = parseFloat(priceInput.value);
    
    if (isNaN(price) || price < 0) {
        alert('Введите корректную цену');
        return;
    }
    
    try {
        await API.updatePrice(id, price);
        alert('✅ Цена обновлена');
        showPage('admin');
    } catch (error) {
        alert('Ошибка: ' + error.message);
    }
};

window.addPrice = async () => {
    const service_id = document.getElementById('newPriceServiceId').value;
    const level_id = document.getElementById('newPriceLevelId').value;
    const price = parseFloat(document.getElementById('newPriceAmount').value);
    
    if (!service_id || isNaN(price)) {
        alert('Заполните все поля');
        return;
    }
    
    try {
        await API.addPrice({ service_id, level_id, price });
        alert('✅ Цена добавлена');
        document.getElementById('newPriceAmount').value = '';
        showPage('admin');
    } catch (error) {
        alert('Ошибка: ' + error.message);
    }
};

// ==================== АДМИН-ПАНЕЛЬ ====================
window.renderAdmin = async function(container) {
    if (!currentUser || currentUser.role_id !== 1) {
        container.innerHTML = '<div class="card"><h3>🔒 Доступ запрещен. Требуются права администратора.</h3></div>';
        return;
    }
    
    container.innerHTML = '<div style="text-align:center;padding:50px;">⏳ Загрузка админ-панели...</div>';
    
    try {
        const [stats, appointments, masters, promotions, clients, services, extraServices, prices] = await Promise.all([
            API.getAdminStats(),
            API.getAdminAppointments(),
            API.getAdminMasters(),
            API.getAdminPromotions(),
            API.getAdminClients(),
            API.getAdminServices(),
            API.getExtraServices(),
            API.getAdminPrices()
        ]);
        
        // Разделяем услуги на основные и дополнительные
        const mainServices = services.filter(s => s.type !== 'extra');
        const extraServicesList = extraServices;
        
        container.innerHTML = `
            <h1>Админ-панель</h1>
            
            <div class="admin-stats">
                <div class="stat-card"><h3>Записей</h3><p>${stats.total_appointments}</p></div>
                <div class="stat-card"><h3>Клиентов</h3><p>${stats.total_clients}</p></div>
                <div class="stat-card"><h3>Мастеров</h3><p>${stats.total_masters}</p></div>
            </div>
            
<!-- ==================== УПРАВЛЕНИЕ ОСНОВНЫМИ УСЛУГАМИ ==================== -->
<h2 style="margin-top: 40px;">Управление услугами</h2>

<!-- Добавить новую услугу -->
<div class="card" style="margin-bottom: 20px;">
    <h3>➕ Добавить услугу</h3>
    <div style="display: flex; gap: 10px; flex-wrap: wrap;">
        <input type="text" id="newServiceName" placeholder="Название услуги" style="flex:2; padding: 8px; border-radius: 8px; border: 1px solid #ddd;">
        <button class="btn-primary" onclick="addNewService()" style="padding: 8px 20px;">➕ Добавить</button>
    </div>
</div>

<!-- Таблица услуг с ценами -->
<div style="overflow-x: auto;">
    <table style="width:100%; border-collapse: collapse;">
        <thead>
            <tr style="background: #fce4ec;">
                <th style="padding: 12px; text-align: left;">Услуга</th>
                <th style="padding: 12px; text-align: center;">Мастер</th>
                <th style="padding: 12px; text-align: center;">Мастер+</th>
                <th style="padding: 12px; text-align: center;">PRO</th>
                <th style="padding: 12px; text-align: center;">Действия</th>
            </tr>
        </thead>
        <tbody id="servicesTableBody">
            ${services.map(service => {
                const priceMaster = prices.find(p => p.service_id == service.id && p.level_id == 1);
                const priceMasterPlus = prices.find(p => p.service_id == service.id && p.level_id == 2);
                const pricePro = prices.find(p => p.service_id == service.id && p.level_id == 3);
                
                return `
                    <tr style="border-bottom: 1px solid #f0dbe2;">
                        <td style="padding: 10px; font-weight: 500;">${service.name}</td>
                        <td style="padding: 10px; text-align: center;">
                            <input type="number" id="price_${service.id}_1" value="${priceMaster ? priceMaster.price : ''}" 
                                   placeholder="Цена" step="100" style="width: 100px; padding: 6px; border-radius: 6px; border: 1px solid #ddd;">
                        </td>
                        <td style="padding: 10px; text-align: center;">
                            <input type="number" id="price_${service.id}_2" value="${priceMasterPlus ? priceMasterPlus.price : ''}" 
                                   placeholder="Цена" step="100" style="width: 100px; padding: 6px; border-radius: 6px; border: 1px solid #ddd;">
                        </td>
                        <td style="padding: 10px; text-align: center;">
                            <input type="number" id="price_${service.id}_3" value="${pricePro ? pricePro.price : ''}" 
                                   placeholder="Цена" step="100" style="width: 100px; padding: 6px; border-radius: 6px; border: 1px solid #ddd;">
                        </td>
                        <td style="padding: 10px; text-align: center;">
                            <button class="btn-save" onclick="saveServicePrices(${service.id})" style="padding: 5px 10px; background: #c76e8e; color: white; border: none; border-radius: 8px; cursor: pointer;">💾 Сохранить</button>
                            <button class="btn-delete" onclick="deleteMainService(${service.id})" style="padding: 5px 10px; background: #f44336; color: white; border: none; border-radius: 8px; cursor: pointer;">🗑️ Удалить</button>
                        </td>
                    </tr>
                `;
            }).join('')}
        </tbody>
    </table>
</div>
            
            <!-- ==================== УПРАВЛЕНИЕ ДОПОЛНИТЕЛЬНЫМИ УСЛУГАМИ ==================== -->
            <h2 style="margin-top: 40px;">Дополнительные услуги</h2>
            
            <!-- Добавить новую дополнительную услугу -->
            <div class="card" style="margin-bottom: 20px;">
                <h3>➕ Добавить дополнительную услугу</h3>
                <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                    <input type="text" id="newExtraServiceName" placeholder="Название" style="flex:2; padding: 8px; border-radius: 8px; border: 1px solid #ddd;">
                    <input type="number" id="newExtraServicePrice" placeholder="Цена" step="50" style="flex:1; padding: 8px; border-radius: 8px; border: 1px solid #ddd;">
                    <button class="btn-primary" onclick="addNewExtraService()" style="padding: 8px 20px;">➕ Добавить</button>
                </div>
            </div>
            
            <!-- Таблица дополнительных услуг -->
            <div style="overflow-x: auto;">
                <table style="width:100%; border-collapse: collapse;">
                    <thead>
                        <tr style="background: #fce4ec;">
                            <th style="padding: 12px; text-align: left;">Услуга</th>
                            <th style="padding: 12px; text-align: center;">Цена</th>
                            <th style="padding: 12px; text-align: center;">Действия</th>
                        </tr>
                    </thead>
                    <tbody id="extraServicesTableBody">
                        ${extraServicesList.map(service => `
                            <tr style="border-bottom: 1px solid #f0dbe2;">
                                <td style="padding: 10px; font-weight: 500;">${service.name}</td>
                                <td style="padding: 10px; text-align: center;">
                                    <input type="number" id="extra_price_${service.id}" value="${service.price}" 
                                           step="50" style="width: 100px; padding: 6px; border-radius: 6px; border: 1px solid #ddd;">
                                </td>
                                <td style="padding: 10px; text-align: center;">
                                    <button class="btn-save" onclick="saveExtraServicePrice(${service.id})" style="padding: 5px 10px; background: #c76e8e; color: white; border: none; border-radius: 8px; cursor: pointer;">💾 Сохранить</button>
                                    <button class="btn-delete" onclick="deleteExtraService(${service.id})" style="padding: 5px 10px; background: #f44336; color: white; border: none; border-radius: 8px; cursor: pointer;">🗑️ Удалить</button>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
            
            <!-- ==================== УПРАВЛЕНИЕ ЗАПИСЯМИ (СВОРАЧИВАЕМЫЙ) ==================== -->
            <div style="margin-top: 40px;">
                <div style="display: flex; align-items: center; gap: 15px; cursor: pointer;" onclick="toggleAppointmentsBlock()">
                    <h2 style="margin: 0;">Управление записями</h2>
                    <span id="toggleIcon" style="font-size: 1.5rem;">▼</span>
                </div>
                
                <div id="appointmentsBlock" style="display: block;">
                    <div style="display: flex; gap: 15px; margin: 20px 0; align-items: flex-end; flex-wrap: wrap; background: #f5f5f5; padding: 15px; border-radius: 15px;">
                        <div>
                            <label style="display: block; margin-bottom: 5px; font-size: 0.85rem;">📅 Дата:</label>
                            <input type="date" id="filterDate" style="padding: 8px; border-radius: 10px; border: 1px solid #ddd;">
                        </div>
                        <div>
                            <label style="display: block; margin-bottom: 5px; font-size: 0.85rem;">💇 Мастер:</label>
                            <select id="filterMaster" style="padding: 8px; border-radius: 10px; border: 1px solid #ddd; min-width: 150px;">
                                <option value="">Все мастера</option>
                                ${masters.map(m => `<option value="${m.id}">${m.name}</option>`).join('')}
                            </select>
                        </div>
                        <button class="btn-primary" onclick="filterAppointments()" style="padding: 8px 20px;">🔍 Показать</button>
                    </div>
                    
                    <div class="table-container">
                        <table style="width:100%; border-collapse: collapse;">
                            <thead>
                                <tr style="background: #fce4ec;">
                                    <th style="padding: 12px; text-align: left;">Клиент</th>
                                    <th style="padding: 12px; text-align: left;">Время</th>
                                    <th style="padding: 12px; text-align: left;">Услуга</th>
                                    <th style="padding: 12px; text-align: left;">Статус</th>
                                    <th style="padding: 12px; text-align: center;">Действие</th>
                                </tr>
                            </thead>
                            <tbody id="appointmentsTableBody">
                                ${appointments.sort((a, b) => {
                                    const timeA = a.appointment_time || '00:00';
                                    const timeB = b.appointment_time || '00:00';
                                    return timeA.localeCompare(timeB);
                                }).map(a => {
                                    let statusClass = '';
                                    let statusText = '';
                                    if (a.status === 'Запланирована') {
                                        statusClass = 'status-planned';
                                        statusText = '🟢 Запланирована';
                                    } else if (a.status === 'Выполнена') {
                                        statusClass = 'status-completed';
                                        statusText = '✅ Выполнена';
                                    } else {
                                        statusClass = 'status-canceled';
                                        statusText = '❌ Отменена';
                                    }
                                    
                                    let time = a.appointment_time || '—';
                                    if (time && time.includes(':')) time = time.substring(0,5);
                                    
                                    return `
                                        <tr style="border-bottom: 1px solid #f0dbe2;">
                                            <td style="padding: 10px;">${a.client_name || '—'}</td>
                                            <td style="padding: 10px;">${time}</td>
                                            <td style="padding: 10px;">${a.service_name || '—'}</td>
                                            <td style="padding: 10px;"><span class="${statusClass}">${statusText}</span></td>
                                            <td style="padding: 10px; text-align: center;">
                                                <select class="status-select" data-id="${a.id}" style="padding: 5px; border-radius: 8px;">
                                                    <option ${a.status === 'Запланирована' ? 'selected' : ''}>Запланирована</option>
                                                    <option ${a.status === 'Выполнена' ? 'selected' : ''}>Выполнена</option>
                                                    <option ${a.status === 'Отменена' ? 'selected' : ''}>Отменена</option>
                                                </select>
                                                <button class="btn-save" onclick="updateAppointmentStatus(${a.id})" style="margin-left: 5px; padding: 5px 10px; background: #c76e8e; color: white; border: none; border-radius: 8px; cursor: pointer;">💾</button>
                                            </td>
                                        </tr>
                                    `;
                                }).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <!-- ==================== УПРАВЛЕНИЕ МАСТЕРАМИ ==================== -->
            <h2 style="margin-top: 40px;">Управление мастерами</h2>
            <div class="table-container">
                <table style="width:100%; border-collapse: collapse;">
                    <thead>
                        <tr style="background: #fce4ec;">
                            <th style="padding: 12px; text-align: left;">Имя</th>
                            <th style="padding: 12px; text-align: left;">Телефон</th>
                            <th style="padding: 12px; text-align: left;">Уровень</th>
                            <th style="padding: 12px; text-align: center;">Действия</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${masters.map(m => `
                            <tr style="border-bottom: 1px solid #f0dbe2;">
                                <td style="padding: 10px;">${m.name}</td>
                                <td style="padding: 10px;">${m.phone}</td>
                                <td style="padding: 10px;">
                                    <select class="level-select" data-id="${m.id}" style="padding: 5px; border-radius: 8px;">
                                        <option value="1" ${m.level_id == 1 ? 'selected' : ''}>Мастер</option>
                                        <option value="2" ${m.level_id == 2 ? 'selected' : ''}>Мастер+</option>
                                        <option value="3" ${m.level_id == 3 ? 'selected' : ''}>PRO</option>
                                    </select>
                                </td>
                                <td style="padding: 10px; text-align: center;">
                                    <button class="btn-save" onclick="saveMasterLevel(${m.id})" style="padding: 5px 10px; background: #c76e8e; color: white; border: none; border-radius: 8px; cursor: pointer;">💾</button>
                                    <button class="btn-delete" onclick="deleteMaster(${m.id})" style="padding: 5px 10px; background: #f44336; color: white; border: none; border-radius: 8px; cursor: pointer;">🗑️</button>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
            
            <div class="card" style="margin-top: 20px;">
                <h3>➕ Добавить мастера</h3>
                <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                    <input type="text" id="newMasterName" placeholder="Имя" style="flex:2; padding: 8px; border-radius: 8px; border: 1px solid #ddd;">
                    <input type="text" id="newMasterPhone" placeholder="Телефон" style="flex:2; padding: 8px; border-radius: 8px; border: 1px solid #ddd;">
                    <select id="newMasterLevel" style="flex:1; padding: 8px; border-radius: 8px; border: 1px solid #ddd;">
                        <option value="1">Мастер</option>
                        <option value="2">Мастер+</option>
                        <option value="3">PRO</option>
                    </select>
                    <button class="btn-primary" onclick="addMaster()" style="padding: 8px 20px;">➕ Добавить</button>
                </div>
            </div>
            
            <!-- ==================== УПРАВЛЕНИЕ АКЦИЯМИ ==================== -->
<h2 style="margin-top: 40px;">🎁 Управление акциями</h2>

<!-- Добавить акцию -->
<div class="card" style="margin-bottom: 20px;">
    <h3>➕ Добавить акцию</h3>
    <div style="display: flex; gap: 10px; flex-wrap: wrap; align-items: flex-end;">
        <div style="flex:1;">
            <label style="display: block; margin-bottom: 5px; font-size: 0.8rem;">Название</label>
            <input type="text" id="promoName" placeholder="Например: Весенняя распродажа" style="width:100%; padding: 8px; border-radius: 8px; border: 1px solid #ddd;">
        </div>
        <div style="width: 100px;">
            <label style="display: block; margin-bottom: 5px; font-size: 0.8rem;">Скидка %</label>
            <input type="number" id="promoDiscount" placeholder="%" step="5" style="width:100%; padding: 8px; border-radius: 8px; border: 1px solid #ddd;">
        </div>
        <div style="width: 140px;">
            <label style="display: block; margin-bottom: 5px; font-size: 0.8rem;">Тип акции</label>
            <select id="promoType" onchange="togglePromotionFields()" style="width:100%; padding: 8px; border-radius: 8px; border: 1px solid #ddd;">
                <option value="standard">📌 Обычная</option>
                <option value="new_client">🆕 Новым клиентам</option>
                <option value="happy_hours">⏰ Счастливые часы</option>
                <option value="seasonal">🌸 Сезонная</option>
            </select>
        </div>
    </div>
    
    <!-- Дополнительные поля для счастливых часов -->
    <div id="happyHoursFields" style="display: none; margin-top: 15px;">
        <label style="display: block; margin-bottom: 5px; font-size: 0.8rem;">⏰ Время действия:</label>
        <div style="display: flex; gap: 10px;">
            <input type="time" id="promoStartTime" placeholder="Начало" style="flex:1; padding: 8px; border-radius: 8px; border: 1px solid #ddd;">
            <span style="line-height: 35px;">—</span>
            <input type="time" id="promoEndTime" placeholder="Конец" style="flex:1; padding: 8px; border-radius: 8px; border: 1px solid #ddd;">
        </div>
        <small style="color: #666;">Пример: 09:00 — 12:00</small>
    </div>
    
    <!-- Дополнительные поля для сезонной акции -->
    <div id="seasonalFields" style="display: none; margin-top: 15px;">
        <label style="display: block; margin-bottom: 5px; font-size: 0.8rem;">📅 Период действия:</label>
        <div style="display: flex; gap: 10px;">
            <input type="date" id="promoStartDate" style="flex:1; padding: 8px; border-radius: 8px; border: 1px solid #ddd;">
            <span style="line-height: 35px;">—</span>
            <input type="date" id="promoEndDate" style="flex:1; padding: 8px; border-radius: 8px; border: 1px solid #ddd;">
        </div>
        <small style="color: #666;">Пример: 2026-04-25 — 2026-05-25</small>
    </div>
    
    <button class="btn-primary" onclick="addPromotion()" style="margin-top: 15px; padding: 8px 20px;">➕ Добавить акцию</button>
</div>

<!-- Таблица акций -->
<div class="table-container">
    <table>
        <thead>
            <tr style="background: #fce4ec;">
                <th style="padding: 12px;">ID</th>
                <th style="padding: 12px;">Название</th>
                <th style="padding: 12px;">Скидка</th>
                <th style="padding: 12px;">Тип</th>
                <th style="padding: 12px;">Условия</th>
                <th style="padding: 12px;">Статус</th>
                <th style="padding: 12px;">Действия</th>
            </tr>
        </thead>
        <tbody id="promotionsTableBody">
            ${promotions.map(p => {
                let conditions = '';
                if (p.promotion_type === 'happy_hours' && p.start_time && p.end_time) {
                    conditions = `🕐 ${p.start_time.substring(0,5)} - ${p.end_time.substring(0,5)}`;
                } else if (p.promotion_type === 'seasonal' && p.start_date && p.end_date) {
                    const start = new Date(p.start_date).toLocaleDateString();
                    const end = new Date(p.end_date).toLocaleDateString();
                    conditions = `📅 ${start} — ${end}`;
                } else if (p.promotion_type === 'new_client') {
                    conditions = '🎁 Первая запись';
                } else {
                    conditions = '📌 На все услуги';
                }
                
                let typeIcon = '📌';
                if (p.promotion_type === 'new_client') typeIcon = '🆕';
                else if (p.promotion_type === 'happy_hours') typeIcon = '⏰';
                else if (p.promotion_type === 'seasonal') typeIcon = '🌸';
                
                return `
                    <tr style="border-bottom: 1px solid #f0dbe2;">
                        <td style="padding: 10px;">${p.id}</td>
                        <td style="padding: 10px;"><strong>${p.name}</strong></td>
                        <td style="padding: 10px;"><span style="color: #4caf50; font-weight: bold;">-${p.discount_percent}%</span></td>
                        <td style="padding: 10px;">${typeIcon} ${p.promotion_type || 'standard'}</td>
                        <td style="padding: 10px; font-size: 0.85rem;">${conditions}</td>
                        <td style="padding: 10px;">
                            <span class="${p.is_active ? 'status-planned' : 'status-canceled'}" style="cursor: pointer;" onclick="togglePromotionStatus(${p.id}, ${!p.is_active})">
                                ${p.is_active ? '🟢 Активна' : '🔴 Отключена'}
                            </span>
                        </td>
                        <td style="padding: 10px; text-align: center;">
                            <button class="btn-save" onclick="editPromotion(${p.id})" style="padding: 5px 10px; background: #c76e8e; color: white; border: none; border-radius: 8px; cursor: pointer;">✏️ Ред.</button>
                            <button class="btn-delete" onclick="deletePromotion(${p.id})" style="padding: 5px 10px; background: #f44336; color: white; border: none; border-radius: 8px; cursor: pointer;">🗑️ Удалить</button>
                        </td>
                    </tr>
                `;
            }).join('')}
        </tbody>
    </table>
</div>
        `;
        
    } catch (error) {
        console.error('Ошибка:', error);
        container.innerHTML = `<div class="card"><h3>❌ Ошибка: ${error.message}</h3></div>`;
    }
};
// ==================== ФИЛЬТРАЦИЯ ЗАПИСЕЙ ====================

window.filterAppointments = async () => {
    const date = document.getElementById('filterDate').value;
    const masterId = document.getElementById('filterMaster').value;
    
    let url = '/api/admin/appointments?';
    const params = [];
    
    if (date) {
        params.push(`date=${date}`);
    }
    if (masterId) {
        params.push(`masterId=${masterId}`);
    }
    
    url += params.join('&');
    
    if (!date && !masterId) {
        alert('Выберите дату или мастера для фильтрации');
        return;
    }
    
    try {
        const response = await fetch(url, {
            headers: { 'Authorization': `Bearer ${token}` }
        });
        const appointments = await response.json();
        
        const tbody = document.getElementById('appointmentsTableBody');
        if (tbody) {
            if (appointments.length === 0) {
                tbody.innerHTML = '<tr><td colspan="5" style="text-align:center; padding: 40px;">❌ Записи не найдены</td></tr>';
            } else {
                // Сортируем по времени
                const sorted = [...appointments].sort((a, b) => {
                    const timeA = a.appointment_time || '00:00';
                    const timeB = b.appointment_time || '00:00';
                    return timeA.localeCompare(timeB);
                });
                
                tbody.innerHTML = sorted.map(a => {
                    let statusClass = '';
                    let statusText = '';
                    if (a.status === 'Запланирована') {
                        statusClass = 'status-planned';
                        statusText = '🟢 Запланирована';
                    } else if (a.status === 'Выполнена') {
                        statusClass = 'status-completed';
                        statusText = '✅ Выполнена';
                    } else {
                        statusClass = 'status-canceled';
                        statusText = '❌ Отменена';
                    }
                    
                    let time = a.appointment_time || '—';
                    if (time && time.includes(':')) time = time.substring(0,5);
                    
                    return `
                        <tr style="border-bottom: 1px solid #f0dbe2;">
                            <td style="padding: 10px;">${a.client_name || '—'}</td>
                            <td style="padding: 10px;">${time}</td>
                            <td style="padding: 10px;">${a.service_name || '—'}</td>
                            <td style="padding: 10px;"><span class="${statusClass}">${statusText}</span></td>
                            <td style="padding: 10px; text-align: center;">
                                <select class="status-select" data-id="${a.id}" style="padding: 5px; border-radius: 8px;">
                                    <option ${a.status === 'Запланирована' ? 'selected' : ''}>Запланирована</option>
                                    <option ${a.status === 'Выполнена' ? 'selected' : ''}>Выполнена</option>
                                    <option ${a.status === 'Отменена' ? 'selected' : ''}>Отменена</option>
                                </select>
                                <button class="btn-save" onclick="updateAppointmentStatus(${a.id})" style="margin-left: 5px; padding: 5px 10px; background: #c76e8e; color: white; border: none; border-radius: 8px; cursor: pointer;">💾</button>
                            </td>
                        </tr>
                    `;
                }).join('');
            }
        }
    } catch (error) {
        alert('Ошибка: ' + error.message);
    }
};

window.showAllAppointments = async () => {
    try {
        const response = await fetch('/api/admin/appointments', {
            headers: { 'Authorization': `Bearer ${token}` }
        });
        const appointments = await response.json();
        
        // Сортируем по дате (сначала новые) и по времени
        const sorted = [...appointments].sort((a, b) => {
            const dateA = new Date(`${a.appointment_date}T${a.appointment_time}`);
            const dateB = new Date(`${b.appointment_date}T${b.appointment_time}`);
            return dateB - dateA;
        });
        
        const tbody = document.getElementById('appointmentsTableBody');
        if (tbody) {
            tbody.innerHTML = sorted.map(a => {
                let formattedDate = a.appointment_date;
                if (formattedDate && formattedDate.includes('T')) formattedDate = formattedDate.split('T')[0];
                if (formattedDate && formattedDate.includes('-')) {
                    const parts = formattedDate.split('-');
                    formattedDate = `${parts[2]}.${parts[1]}.${parts[0]}`;
                }
                let formattedTime = a.appointment_time;
                if (formattedTime && formattedTime.includes(':')) formattedTime = formattedTime.substring(0, 5);
                
                let statusClass = '';
                let statusText = '';
                if (a.status === 'Запланирована') {
                    statusClass = 'status-planned';
                    statusText = '🟢 Запланирована';
                } else if (a.status === 'Выполнена') {
                    statusClass = 'status-completed';
                    statusText = '✅ Выполнена';
                } else {
                    statusClass = 'status-canceled';
                    statusText = '❌ Отменена';
                }
                
                return `
                    <tr style="border-bottom: 1px solid #f0dbe2;">
                        <td style="padding: 10px;">${a.client_name || '—'}</td>
                        <td style="padding: 10px;">${a.master_name || '—'}</td>
                        <td style="padding: 10px;">${formattedDate || '—'}</td>
                        <td style="padding: 10px;">${formattedTime || '—'}</td>
                        <td style="padding: 10px;">${a.service_name || '—'}</td>
                        <td style="padding: 10px;"><span class="${statusClass}">${statusText}</span></td>
                        <td style="padding: 10px; text-align: center;">
                            <select class="status-select" data-id="${a.id}" style="padding: 5px; border-radius: 8px;">
                                <option ${a.status === 'Запланирована' ? 'selected' : ''}>Запланирована</option>
                                <option ${a.status === 'Выполнена' ? 'selected' : ''}>Выполнена</option>
                                <option ${a.status === 'Отменена' ? 'selected' : ''}>Отменена</option>
                            </select>
                            <button class="btn-save" onclick="updateAppointmentStatus(${a.id})" style="margin-left: 5px; padding: 5px 10px; background: #c76e8e; color: white; border: none; border-radius: 8px; cursor: pointer;">💾</button>
                        </td>
                    </tr>
                `;
            }).join('');
        }
        
        // Очищаем поля фильтра
        const filterDate = document.getElementById('filterDate');
        const filterMaster = document.getElementById('filterMaster');
        if (filterDate) filterDate.value = '';
        if (filterMaster) filterMaster.value = '';
        
    } catch (error) {
        alert('Ошибка: ' + error.message);
    }
};

window.showAllAppointments = async () => {
    try {
        const response = await fetch('/api/admin/appointments', {
            headers: { 'Authorization': `Bearer ${token}` }
        });
        const appointments = await response.json();
        
        const tbody = document.getElementById('appointmentsTableBody');
        if (tbody) {
            tbody.innerHTML = appointments.map(a => {
                let formattedDate = a.appointment_date;
                if (formattedDate && formattedDate.includes('T')) formattedDate = formattedDate.split('T')[0];
                let formattedTime = a.appointment_time;
                if (formattedTime && formattedTime.includes(':')) formattedTime = formattedTime.substring(0, 5);
                return `
                    <tr>
                        <td>${a.client_name || '—'}</td>
                        <td>${a.master_name || '—'}</td>
                        <tr>${formattedDate || '—'}</td>
                        <td>${formattedTime || '—'}</td>
                        <td>${a.service_name || '—'}</table>
                        <td>
                            <select class="status-select" data-id="${a.id}">
                                <option ${a.status === 'Запланирована' ? 'selected' : ''}>Запланирована</option>
                                <option ${a.status === 'Выполнена' ? 'selected' : ''}>Выполнена</option>
                                <option ${a.status === 'Отменена' ? 'selected' : ''}>Отменена</option>
                            </select>
                        </td>
                        <td><button class="btn-save" onclick="updateAppointmentStatus(${a.id})">💾 Сохранить</button></td>
                    </tr>
                `;
            }).join('');
        }
        
        // Очищаем поля фильтра
        const filterDate = document.getElementById('filterDate');
        const filterMaster = document.getElementById('filterMaster');
        if (filterDate) filterDate.value = '';
        if (filterMaster) filterMaster.value = '';
        
    } catch (error) {
        alert('Ошибка: ' + error.message);
    }
};

window.addPromotion = async () => {
    const name = document.getElementById('promoName').value;
    const discount_percent = parseInt(document.getElementById('promoDiscount').value);
    const promotion_type = document.getElementById('promoType').value;
    
    if (!name || !discount_percent) {
        alert('Заполните название и скидку');
        return;
    }
    
    try {
        await API.addPromotion({ name, discount_percent, promotion_type });
        alert('✅ Акция добавлена');
        document.getElementById('promoName').value = '';
        document.getElementById('promoDiscount').value = '';
        showPage('admin');
    } catch (error) {
        alert('Ошибка: ' + error.message);
    }
};

// Убеждаемся, что функция доступна глобально
window.renderAdmin = window.renderAdmin;

console.log('✅ Админ-панель загружена, renderAdmin доступна');


// ==================== СВЕРТЫВАНИЕ БЛОКА ЗАПИСЕЙ ====================

window.toggleAppointmentsBlock = () => {
    const block = document.getElementById('appointmentsBlock');
    const icon = document.getElementById('toggleIcon');
    
    if (block && icon) {
        if (block.style.display === 'none') {
            block.style.display = 'block';
            icon.innerHTML = '▼';
        } else {
            block.style.display = 'none';
            icon.innerHTML = '▶';
        }
    }
};

// ==================== УПРАВЛЕНИЕ УСЛУГАМИ ====================

window.addNewService = async () => {
    const name = document.getElementById('newServiceName')?.value;
    
    console.log('📝 Отправка названия:', name);
    
    if (!name) {
        alert('Введите название услуги');
        return;
    }
    
    try {
        const response = await fetch('/api/admin/services', {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ name })
        });
        
        console.log('📊 Статус ответа:', response.status);
        
        const data = await response.json();
        console.log('📥 Ответ:', data);
        
        if (response.ok) {
            alert('✅ Услуга "' + name + '" добавлена');
            document.getElementById('newServiceName').value = '';
            showPage('admin');
        } else {
            alert('❌ Ошибка: ' + (data.error || 'Неизвестная ошибка'));
        }
    } catch (error) {
        console.error('❌ Ошибка:', error);
        alert('Ошибка: ' + error.message);
    }
};

// Сохранить цены для услуги
window.saveServicePrices = async (serviceId) => {
    const priceMaster = document.getElementById(`price_${serviceId}_1`)?.value;
    const priceMasterPlus = document.getElementById(`price_${serviceId}_2`)?.value;
    const pricePro = document.getElementById(`price_${serviceId}_3`)?.value;
    
    try {
        if (priceMaster && !isNaN(parseFloat(priceMaster))) {
            await API.addPrice({ service_id: serviceId, level_id: 1, price: parseFloat(priceMaster) });
        }
        if (priceMasterPlus && !isNaN(parseFloat(priceMasterPlus))) {
            await API.addPrice({ service_id: serviceId, level_id: 2, price: parseFloat(priceMasterPlus) });
        }
        if (pricePro && !isNaN(parseFloat(pricePro))) {
            await API.addPrice({ service_id: serviceId, level_id: 3, price: parseFloat(pricePro) });
        }
        
        alert('✅ Цены сохранены');
        showPage('admin');
    } catch (error) {
        alert('Ошибка: ' + error.message);
    }
};

// Удалить услугу
window.deleteMainService = async (serviceId) => {
    if (confirm('Удалить услугу? Это также удалит все связанные цены.')) {
        try {
            await API.deleteService(serviceId);
            alert('✅ Услуга удалена');
            showPage('admin');
        } catch (error) {
            alert('Ошибка: ' + error.message);
        }
    }
};

// ==================== УПРАВЛЕНИЕ ДОПОЛНИТЕЛЬНЫМИ УСЛУГАМИ ====================

// Добавить дополнительную услугу
window.addNewExtraService = async () => {
    const name = document.getElementById('newExtraServiceName')?.value;
    const price = parseFloat(document.getElementById('newExtraServicePrice')?.value);
    
    if (!name || !price) {
        alert('Введите название и цену');
        return;
    }
    
    try {
        const response = await fetch('/api/admin/extra-services', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
            body: JSON.stringify({ name, price })
        });
        
        if (response.ok) {
            alert('✅ Дополнительная услуга добавлена');
            document.getElementById('newExtraServiceName').value = '';
            document.getElementById('newExtraServicePrice').value = '';
            showPage('admin');
        } else {
            alert('❌ Ошибка');
        }
    } catch (error) {
        alert('Ошибка: ' + error.message);
    }
};

// Сохранить цену дополнительной услуги
window.saveExtraServicePrice = async (serviceId) => {
    const price = parseFloat(document.getElementById(`extra_price_${serviceId}`)?.value);
    
    if (isNaN(price)) {
        alert('Введите корректную цену');
        return;
    }
    
    try {
        const response = await fetch(`/api/admin/extra-services/${serviceId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
            body: JSON.stringify({ price })
        });
        
        if (response.ok) {
            alert('✅ Цена обновлена');
            showPage('admin');
        } else {
            alert('❌ Ошибка');
        }
    } catch (error) {
        alert('Ошибка: ' + error.message);
    }
};

// Удалить дополнительную услугу
window.deleteExtraService = async (serviceId) => {
    if (confirm('Удалить дополнительную услугу?')) {
        try {
            const response = await fetch(`/api/admin/extra-services/${serviceId}`, {
                method: 'DELETE',
                headers: { 'Authorization': `Bearer ${token}` }
            });
            
            if (response.ok) {
                alert('✅ Дополнительная услуга удалена');
                showPage('admin');
            } else {
                alert('❌ Ошибка');
            }
        } catch (error) {
            alert('Ошибка: ' + error.message);
        }
    }
};

// ==================== УПРАВЛЕНИЕ АКЦИЯМИ ====================

// Добавить акцию
window.addPromotion = async () => {
    const name = document.getElementById('promoName')?.value;
    const discount_percent = parseInt(document.getElementById('promoDiscount')?.value);
    const promotion_type = document.getElementById('promoType')?.value;
    
    if (!name || !discount_percent) {
        alert('Заполните название и скидку');
        return;
    }
    
    try {
        await API.addPromotion({ name, discount_percent, promotion_type });
        alert('✅ Акция добавлена');
        document.getElementById('promoName').value = '';
        document.getElementById('promoDiscount').value = '';
        showPage('admin');
    } catch (error) {
        alert('Ошибка: ' + error.message);
    }
};

// ==================== ФИЛЬТРАЦИЯ ЗАПИСЕЙ ====================

window.filterAppointments = async () => {
    const date = document.getElementById('filterDate')?.value;
    const masterId = document.getElementById('filterMaster')?.value;
    
    let url = '/api/admin/appointments?';
    const params = [];
    
    if (date) params.push(`date=${date}`);
    if (masterId) params.push(`masterId=${masterId}`);
    
    url += params.join('&');
    
    if (!date && !masterId) {
        alert('Выберите дату или мастера для фильтрации');
        return;
    }
    
    try {
        const response = await fetch(url, {
            headers: { 'Authorization': `Bearer ${token}` }
        });
        const appointments = await response.json();
        
        const tbody = document.getElementById('appointmentsTableBody');
        if (tbody) {
            if (appointments.length === 0) {
                tbody.innerHTML = '<tr><td colspan="5" style="text-align:center; padding: 40px;">❌ Записи не найдены</td></tr>';
            } else {
                const sorted = [...appointments].sort((a, b) => {
                    const timeA = a.appointment_time || '00:00';
                    const timeB = b.appointment_time || '00:00';
                    return timeA.localeCompare(timeB);
                });
                
                tbody.innerHTML = sorted.map(a => {
                    let statusClass = '';
                    let statusText = '';
                    if (a.status === 'Запланирована') {
                        statusClass = 'status-planned';
                        statusText = '🟢 Запланирована';
                    } else if (a.status === 'Выполнена') {
                        statusClass = 'status-completed';
                        statusText = '✅ Выполнена';
                    } else {
                        statusClass = 'status-canceled';
                        statusText = '❌ Отменена';
                    }
                    
                    let time = a.appointment_time || '—';
                    if (time && time.includes(':')) time = time.substring(0,5);
                    
                    return `
                        <tr style="border-bottom: 1px solid #f0dbe2;">
                            <td style="padding: 10px;">${a.client_name || '—'}${a.client_phone ? '<br><small>' + a.client_phone + '</small>' : ''}</td>
                            <td style="padding: 10px;">${time}</td>
                            <td style="padding: 10px;">${a.service_name || '—'}</td>
                            <td style="padding: 10px;"><span class="${statusClass}">${statusText}</span></td>
                            <td style="padding: 10px; text-align: center;">
                                <select class="status-select" data-id="${a.id}" style="padding: 5px; border-radius: 8px;">
                                    <option ${a.status === 'Запланирована' ? 'selected' : ''}>Запланирована</option>
                                    <option ${a.status === 'Выполнена' ? 'selected' : ''}>Выполнена</option>
                                    <option ${a.status === 'Отменена' ? 'selected' : ''}>Отменена</option>
                                </select>
                                <button class="btn-save" onclick="updateAppointmentStatus(${a.id})" style="margin-left: 5px; padding: 5px 10px; background: #c76e8e; color: white; border: none; border-radius: 8px; cursor: pointer;">💾</button>
                            </td>
                        </tr>
                    `;
                }).join('');
            }
        }
    } catch (error) {
        alert('Ошибка: ' + error.message);
    }
};
// ==================== УПРАВЛЕНИЕ АКЦИЯМИ ====================

// Показать/скрыть дополнительные поля
window.togglePromotionFields = () => {
    const type = document.getElementById('promoType')?.value;
    const happyFields = document.getElementById('happyHoursFields');
    const seasonalFields = document.getElementById('seasonalFields');
    
    if (happyFields) happyFields.style.display = type === 'happy_hours' ? 'flex' : 'none';
    if (seasonalFields) seasonalFields.style.display = type === 'seasonal' ? 'flex' : 'none';
};

// Добавить акцию
window.addPromotion = async () => {
    const name = document.getElementById('promoName')?.value;
    const discount_percent = parseInt(document.getElementById('promoDiscount')?.value);
    const promotion_type = document.getElementById('promoType')?.value;
    
    if (!name || !discount_percent) {
        alert('Заполните название и скидку');
        return;
    }
    
    const body = { name, discount_percent, promotion_type };
    
    if (promotion_type === 'happy_hours') {
        body.start_time = document.getElementById('promoStartTime')?.value;
        body.end_time = document.getElementById('promoEndTime')?.value;
        if (!body.start_time || !body.end_time) {
            alert('Укажите время начала и окончания');
            return;
        }
    }
    
    if (promotion_type === 'seasonal') {
        body.start_date = document.getElementById('promoStartDate')?.value;
        body.end_date = document.getElementById('promoEndDate')?.value;
        if (!body.start_date || !body.end_date) {
            alert('Укажите даты начала и окончания');
            return;
        }
    }
    
    try {
        const response = await fetch('/api/admin/promotions', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
            body: JSON.stringify(body)
        });
        
        if (response.ok) {
            alert('✅ Акция добавлена');
            document.getElementById('promoName').value = '';
            document.getElementById('promoDiscount').value = '';
            document.getElementById('promoStartTime').value = '';
            document.getElementById('promoEndTime').value = '';
            document.getElementById('promoStartDate').value = '';
            document.getElementById('promoEndDate').value = '';
            showPage('admin');
        } else {
            const error = await response.json();
            alert('❌ Ошибка: ' + (error.error || 'Неизвестная ошибка'));
        }
    } catch (error) {
        alert('Ошибка: ' + error.message);
    }
};

// Включить/отключить акцию
window.togglePromotionStatus = async (id, newStatus) => {
    try {
        const response = await fetch(`/api/admin/promotions/${id}/toggle`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
            body: JSON.stringify({ is_active: newStatus })
        });
        
        if (response.ok) {
            alert(newStatus ? '✅ Акция активирована' : '🔴 Акция отключена');
            showPage('admin');
        } else {
            alert('❌ Ошибка');
        }
    } catch (error) {
        alert('Ошибка: ' + error.message);
    }
};

// Редактировать акцию
window.editPromotion = async (id) => {
    const newName = prompt('Введите новое название акции:');
    if (!newName) return;
    
    const newDiscount = parseInt(prompt('Введите новый процент скидки (1-100):'));
    if (!newDiscount || newDiscount < 1 || newDiscount > 100) return;
    
    try {
        const response = await fetch(`/api/admin/promotions/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
            body: JSON.stringify({ name: newName, discount_percent: newDiscount })
        });
        
        if (response.ok) {
            alert('✅ Акция обновлена');
            showPage('admin');
        } else {
            alert('❌ Ошибка');
        }
    } catch (error) {
        alert('Ошибка: ' + error.message);
    }
};

// Удалить акцию
window.deletePromotion = async (id) => {
    if (confirm('Удалить эту акцию?')) {
        try {
            const response = await fetch(`/api/admin/promotions/${id}`, {
                method: 'DELETE',
                headers: { 'Authorization': `Bearer ${token}` }
            });
            
            if (response.ok) {
                alert('✅ Акция удалена');
                showPage('admin');
            } else {
                alert('❌ Ошибка');
            }
        } catch (error) {
            alert('Ошибка: ' + error.message);
        }
    }
};
// Запуск
init();