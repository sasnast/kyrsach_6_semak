const express = require('express');
const db = require('../db');
const { authenticateToken, isAdmin } = require('../middleware/auth');
const router = express.Router();

// Все маршруты требуют прав администратора
router.use(authenticateToken, isAdmin);

// ==================== СТАТИСТИКА ====================
router.get('/stats', async (req, res) => {
    console.log('📊 Запрос статистики');
    
    try {
        const appointments = await db.query('SELECT COUNT(*) FROM appointments');
        const clients = await db.query('SELECT COUNT(*) FROM clients');
        const masters = await db.query('SELECT COUNT(*) FROM masters');
        const completed = await db.query("SELECT COUNT(*) FROM appointments WHERE status = 'Выполнена'");
        
        const stats = {
            total_appointments: parseInt(appointments.rows[0].count),
            total_clients: parseInt(clients.rows[0].count),
            total_masters: parseInt(masters.rows[0].count),
            completed_appointments: parseInt(completed.rows[0].count)
        };
        
        console.log('✅ Статистика:', stats);
        res.json(stats);
    } catch (error) {
        console.error('❌ Ошибка получения статистики:', error);
        res.status(500).json({ error: 'Ошибка получения статистики' });
    }
});

// ==================== ЗАПИСИ (ЕДИНСТВЕННАЯ ВЕРСИЯ) ====================
router.get('/appointments', async (req, res) => {
    const { date, masterId } = req.query;
    
    try {
        let query = `
            SELECT 
                a.id,
                TO_CHAR(a.appointment_date, 'DD.MM.YYYY') as appointment_date,
                TO_CHAR(a.appointment_time, 'HH24:MI') as appointment_time,
                a.status,
                c.name as client_name,
                m.name as master_name,
                s.name as service_name
            FROM appointments a
            JOIN clients c ON a.client_id = c.id
            JOIN masters m ON a.master_id = m.id
            LEFT JOIN appointment_services app_s ON a.id = app_s.appointment_id
            LEFT JOIN services s ON app_s.service_id = s.id
            WHERE 1=1
        `;
        let params = [];
        let paramIndex = 1;
        
        if (date) {
            query += ` AND a.appointment_date::date = $${paramIndex}::date`;
            params.push(date);
            paramIndex++;
        }
        
        if (masterId) {
            query += ` AND a.master_id = $${paramIndex}`;
            params.push(masterId);
            paramIndex++;
        }
        
        query += ` ORDER BY a.appointment_date DESC, a.appointment_time ASC`;
        
        const result = await db.query(query, params);
        res.json(result.rows);
    } catch (error) {
        console.error('Ошибка получения записей:', error);
        res.status(500).json({ error: 'Ошибка получения записей' });
    }
});

// Обновить статус записи
router.put('/appointments/:id/status', async (req, res) => {
    const { status } = req.body;
    const { id } = req.params;
    
    try {
        await db.query('UPDATE appointments SET status = $1 WHERE id = $2', [status, id]);
        res.json({ success: true });
    } catch (error) {
        console.error('Ошибка:', error);
        res.status(500).json({ error: 'Ошибка обновления статуса' });
    }
});

// ==================== МАСТЕРА ====================
router.get('/masters', async (req, res) => {
    console.log('📋 Запрос всех мастеров (админ)');
    
    try {
        const result = await db.query(`
            SELECT m.*, ml.name as level_name
            FROM masters m
            JOIN master_levels ml ON m.level_id = ml.id
            ORDER BY m.name
        `);
        
        console.log(`✅ Найдено мастеров: ${result.rows.length}`);
        res.json(result.rows);
    } catch (error) {
        console.error('❌ Ошибка получения мастеров:', error);
        res.status(500).json({ error: 'Ошибка получения мастеров' });
    }
});

router.post('/masters', async (req, res) => {
    const { name, phone, level_id } = req.body;
    
    if (!name || !phone || !level_id) {
        return res.status(400).json({ error: 'Все поля обязательны' });
    }
    
    try {
        const result = await db.query(
            'INSERT INTO masters (name, phone, level_id) VALUES ($1, $2, $3) RETURNING *',
            [name, phone, level_id]
        );
        res.json(result.rows[0]);
    } catch (error) {
        console.error('❌ Ошибка добавления мастера:', error);
        res.status(500).json({ error: 'Ошибка добавления мастера' });
    }
});

router.put('/masters/:id/level', async (req, res) => {
    const { level_id } = req.body;
    const { id } = req.params;
    
    try {
        await db.query('UPDATE masters SET level_id = $1 WHERE id = $2', [level_id, id]);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ error: 'Ошибка обновления уровня' });
    }
});

router.delete('/masters/:id', async (req, res) => {
    const { id } = req.params;
    
    try {
        await db.query('DELETE FROM appointment_extra_services WHERE extra_service_id IN (SELECT id FROM extra_services)', []);
        await db.query('DELETE FROM appointment_services WHERE appointment_id IN (SELECT id FROM appointments WHERE master_id = $1)', [id]);
        await db.query('DELETE FROM appointments WHERE master_id = $1', [id]);
        await db.query('DELETE FROM masters WHERE id = $1', [id]);
        
        res.json({ success: true });
    } catch (error) {
        console.error('Ошибка:', error);
        res.status(500).json({ error: 'Ошибка удаления мастера' });
    }
});

// ==================== УСЛУГИ ====================
router.get('/services', async (req, res) => {
    try {
        const result = await db.query('SELECT * FROM services ORDER BY id');
        res.json(result.rows);
    } catch (error) {
        console.error('Ошибка:', error);
        res.status(500).json({ error: 'Ошибка получения услуг' });
    }
});

router.post('/services', async (req, res) => {
    const { name } = req.body;
    
    console.log('📝 Добавление услуги, название:', name);
    
    if (!name) {
        return res.status(400).json({ error: 'Название услуги обязательно' });
    }
    
    try {
        const result = await db.query(
            'INSERT INTO services (name) VALUES ($1) RETURNING *',
            [name]
        );
        console.log('✅ Услуга добавлена, ID:', result.rows[0].id);
        res.json(result.rows[0]);
    } catch (error) {
        console.error('❌ Ошибка SQL:', error);
        res.status(500).json({ error: 'Ошибка добавления услуги: ' + error.message });
    }
});

router.delete('/services/:id', async (req, res) => {
    const { id } = req.params;
    
    try {
        await db.query('DELETE FROM prices WHERE service_id = $1', [id]);
        await db.query('DELETE FROM services WHERE id = $1', [id]);
        res.json({ success: true });
    } catch (error) {
        console.error('Ошибка:', error);
        res.status(500).json({ error: 'Ошибка удаления услуги' });
    }
});

// ==================== ПРАЙС-ЛИСТ ====================
router.get('/prices', async (req, res) => {
    try {
        const result = await db.query(`
            SELECT p.*, s.name as service_name, ml.name as level_name
            FROM prices p
            JOIN services s ON p.service_id = s.id
            JOIN master_levels ml ON p.level_id = ml.id
            ORDER BY s.id, p.level_id
        `);
        res.json(result.rows);
    } catch (error) {
        console.error('Ошибка:', error);
        res.status(500).json({ error: 'Ошибка получения цен' });
    }
});

router.put('/prices/:id', async (req, res) => {
    const { id } = req.params;
    const { price } = req.body;
    
    try {
        await db.query('UPDATE prices SET price = $1 WHERE id = $2', [price, id]);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ error: 'Ошибка обновления цены' });
    }
});

router.post('/prices', async (req, res) => {
    const { service_id, level_id, price } = req.body;
    
    try {
        const existing = await db.query(
            'SELECT id FROM prices WHERE service_id = $1 AND level_id = $2',
            [service_id, level_id]
        );
        
        if (existing.rows.length > 0) {
            await db.query('UPDATE prices SET price = $1 WHERE service_id = $2 AND level_id = $3', [price, service_id, level_id]);
        } else {
            await db.query('INSERT INTO prices (service_id, level_id, price) VALUES ($1, $2, $3)', [service_id, level_id, price]);
        }
        res.json({ success: true });
    } catch (error) {
        console.error('Ошибка:', error);
        res.status(500).json({ error: 'Ошибка добавления цены' });
    }
});

// ==================== ДОПОЛНИТЕЛЬНЫЕ УСЛУГИ ====================
router.get('/extra-services', async (req, res) => {
    try {
        const result = await db.query('SELECT * FROM extra_services ORDER BY name');
        res.json(result.rows);
    } catch (error) {
        console.error('Ошибка:', error);
        res.status(500).json({ error: 'Ошибка получения доп. услуг' });
    }
});

router.post('/extra-services', async (req, res) => {
    const { name, price } = req.body;
    
    if (!name || price === undefined) {
        return res.status(400).json({ error: 'Название и цена обязательны' });
    }
    
    try {
        const result = await db.query(
            'INSERT INTO extra_services (name, price) VALUES ($1, $2) RETURNING *',
            [name, price]
        );
        res.json(result.rows[0]);
    } catch (error) {
        console.error('Ошибка:', error);
        res.status(500).json({ error: 'Ошибка добавления доп. услуги' });
    }
});

router.put('/extra-services/:id', async (req, res) => {
    const { id } = req.params;
    const { price } = req.body;
    
    try {
        const result = await db.query('UPDATE extra_services SET price = $1 WHERE id = $2 RETURNING *', [price, id]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Доп. услуга не найдена' });
        }
        res.json(result.rows[0]);
    } catch (error) {
        console.error('Ошибка:', error);
        res.status(500).json({ error: 'Ошибка обновления доп. услуги' });
    }
});

router.delete('/extra-services/:id', async (req, res) => {
    const { id } = req.params;
    
    try {
        await db.query('DELETE FROM appointment_extra_services WHERE extra_service_id = $1', [id]);
        const result = await db.query('DELETE FROM extra_services WHERE id = $1 RETURNING id', [id]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Доп. услуга не найдена' });
        }
        res.json({ success: true });
    } catch (error) {
        console.error('Ошибка:', error);
        res.status(500).json({ error: 'Ошибка удаления доп. услуги' });
    }
});

// ==================== УПРАВЛЕНИЕ АКЦИЯМИ (РАСШИРЕННОЕ) ====================

// Получить все акции
router.get('/promotions', async (req, res) => {
    try {
        const result = await db.query('SELECT * FROM promotions ORDER BY id');
        res.json(result.rows);
    } catch (error) {
        console.error('Ошибка:', error);
        res.status(500).json({ error: 'Ошибка получения акций' });
    }
});

// Добавить акцию (с поддержкой всех типов)
router.post('/promotions', async (req, res) => {
    const { name, discount_percent, promotion_type, start_time, end_time, start_date, end_date } = req.body;
    
    console.log('➕ Добавление акции:', { name, discount_percent, promotion_type });
    
    if (!name || discount_percent === undefined) {
        return res.status(400).json({ error: 'Название и процент скидки обязательны' });
    }
    
    if (discount_percent < 0 || discount_percent > 100) {
        return res.status(400).json({ error: 'Скидка должна быть от 0 до 100' });
    }
    
    try {
        const result = await db.query(
            `INSERT INTO promotions (name, discount_percent, promotion_type, start_time, end_time, start_date, end_date, is_active) 
             VALUES ($1, $2, $3, $4, $5, $6, $7, true) 
             RETURNING *`,
            [name, discount_percent, promotion_type || 'standard', start_time || null, end_time || null, start_date || null, end_date || null]
        );
        console.log('✅ Акция добавлена, ID:', result.rows[0].id);
        res.json(result.rows[0]);
    } catch (error) {
        console.error('❌ Ошибка добавления акции:', error);
        res.status(500).json({ error: 'Ошибка добавления акции: ' + error.message });
    }
});

// Обновить акцию
router.put('/promotions/:id', async (req, res) => {
    const { id } = req.params;
    const { name, discount_percent, promotion_type, start_time, end_time, start_date, end_date, is_active } = req.body;
    
    console.log('✏️ Обновление акции ID:', id);
    
    try {
        const result = await db.query(
            `UPDATE promotions 
             SET name = COALESCE($1, name),
                 discount_percent = COALESCE($2, discount_percent),
                 promotion_type = COALESCE($3, promotion_type),
                 start_time = $4,
                 end_time = $5,
                 start_date = $6,
                 end_date = $7,
                 is_active = COALESCE($8, is_active)
             WHERE id = $9
             RETURNING *`,
            [name, discount_percent, promotion_type, start_time || null, end_time || null, start_date || null, end_date || null, is_active, id]
        );
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Акция не найдена' });
        }
        
        console.log('✅ Акция обновлена');
        res.json(result.rows[0]);
    } catch (error) {
        console.error('❌ Ошибка обновления акции:', error);
        res.status(500).json({ error: 'Ошибка обновления акции' });
    }
});

// Удалить акцию
router.delete('/promotions/:id', async (req, res) => {
    const { id } = req.params;
    
    console.log('🗑️ Удаление акции ID:', id);
    
    try {
        const result = await db.query('DELETE FROM promotions WHERE id = $1 RETURNING id', [id]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Акция не найдена' });
        }
        
        console.log('✅ Акция удалена');
        res.json({ success: true });
    } catch (error) {
        console.error('❌ Ошибка удаления акции:', error);
        res.status(500).json({ error: 'Ошибка удаления акции' });
    }
});

// Включить/отключить акцию
router.patch('/promotions/:id/toggle', async (req, res) => {
    const { id } = req.params;
    const { is_active } = req.body;
    
    try {
        await db.query('UPDATE promotions SET is_active = $1 WHERE id = $2', [is_active, id]);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ error: 'Ошибка изменения статуса' });
    }
});

// ==================== КЛИЕНТЫ ====================
router.get('/clients', async (req, res) => {
    try {
        const result = await db.query(`
            SELECT c.*, u.login 
            FROM clients c
            LEFT JOIN users u ON c.id = u.client_id
            ORDER BY c.name
        `);
        res.json(result.rows);
    } catch (error) {
        res.status(500).json({ error: 'Ошибка получения клиентов' });
    }
});

// ТЕСТОВЫЙ МАРШРУТ (добавьте перед module.exports)
router.post('/test-service', async (req, res) => {
    console.log('🔧 ТЕСТОВЫЙ МАРШРУТ ВЫЗВАН');
    console.log('📦 Данные:', req.body);
    
    try {
        // Простейшая вставка
        const result = await db.query(
            'INSERT INTO services (name) VALUES ($1) RETURNING id',
            ['Тестовая услуга ' + new Date().getTime()]
        );
        res.json({ success: true, id: result.rows[0].id });
    } catch (error) {
        console.error('❌ Ошибка теста:', error);
        res.status(500).json({ error: error.message });
    }
});


module.exports = router;