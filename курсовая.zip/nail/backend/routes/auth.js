const express = require('express');
const jwt = require('jsonwebtoken');
const db = require('../db');
const router = express.Router();

// ==================== РЕГИСТРАЦИЯ ====================
router.post('/register', async (req, res) => {
    const { login, password, name, phone } = req.body;
    
    console.log('📝 Попытка регистрации:', { login, name, phone });
    
    // Проверка обязательных полей
    if (!login || !password || !name || !phone) {
        console.log('❌ Не все поля заполнены');
        return res.status(400).json({ error: 'Все поля обязательны' });
    }

    try {
        // Проверка существования пользователя
        const existingUser = await db.query(
            'SELECT id FROM users WHERE login = $1',
            [login]
        );
        
        if (existingUser.rows.length > 0) {
            console.log('❌ Пользователь уже существует:', login);
            return res.status(400).json({ error: 'Пользователь с таким логином уже существует' });
        }
        
        // Создаем клиента
        const clientResult = await db.query(
            'INSERT INTO clients (name, phone) VALUES ($1, $2) RETURNING id',
            [name, phone]
        );
        const clientId = clientResult.rows[0].id;
        console.log('✅ Создан клиент с ID:', clientId);
        
        // Создаем пользователя
        await db.query(
            'INSERT INTO users (login, password, role_id, client_id) VALUES ($1, $2, 2, $3)',
            [login, password, clientId]
        );
        
        console.log('✅ Пользователь успешно зарегистрирован:', login);
        res.json({ 
            success: true, 
            message: 'Регистрация успешна! Теперь вы можете войти'
        });
        
    } catch (error) {
        console.error('❌ Ошибка регистрации:', error);
        res.status(500).json({ error: 'Ошибка при регистрации: ' + error.message });
    }
});

// ==================== ВХОД ====================
router.post('/login', async (req, res) => {
    const { login, password } = req.body;
    
    console.log('🔐 Попытка входа:', login);
    
    if (!login || !password) {
        console.log('❌ Логин или пароль не указаны');
        return res.status(400).json({ error: 'Логин и пароль обязательны' });
    }
    
    try {
        // Ищем пользователя
        const result = await db.query(`
            SELECT u.*, r.name as role_name, c.id as client_id, c.name as client_name
            FROM users u
            JOIN roles r ON u.role_id = r.id
            LEFT JOIN clients c ON u.client_id = c.id
            WHERE u.login = $1 AND u.password = $2
        `, [login, password]);
        
        if (result.rows.length === 0) {
            console.log('❌ Неверный логин или пароль для:', login);
            return res.status(401).json({ error: 'Неверный логин или пароль' });
        }
        
        const user = result.rows[0];
        console.log('✅ Пользователь найден:', { 
            id: user.id, 
            login: user.login, 
            role: user.role_name,
            client_id: user.client_id 
        });
        
        // Создаем JWT токен
        const token = jwt.sign(
            { 
                id: user.id, 
                login: user.login, 
                role_id: user.role_id,
                client_id: user.client_id
            },
            process.env.JWT_SECRET,
            { expiresIn: '24h' }
        );
        
        console.log('✅ Токен создан, вход выполнен');
        
        res.json({
            token,
            user: {
                id: user.id,
                login: user.login,
                role_id: user.role_id,
                role_name: user.role_name,
                client_id: user.client_id,
                client_name: user.client_name
            }
        });
        
    } catch (error) {
        console.error('❌ Ошибка входа:', error);
        res.status(500).json({ error: 'Ошибка при входе: ' + error.message });
    }
});

module.exports = router;