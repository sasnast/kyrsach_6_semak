const express = require('express');
const db = require('../db');
const router = express.Router();
const { authenticateToken } = require('../middleware/auth');

// ==================== ПОЛУЧИТЬ ВСЕХ МАСТЕРОВ ====================
router.get('/', async (req, res) => {
    try {
        const result = await db.query(`
            SELECT m.*, ml.name as level_name
            FROM masters m
            JOIN master_levels ml ON m.level_id = ml.id
            ORDER BY m.name
        `);
        res.json(result.rows);
    } catch (error) {
        res.status(500).json({ error: 'Ошибка получения мастеров' });
    }
});

// ==================== ПОЛУЧИТЬ МАСТЕРА ПО ID ====================
router.get('/:id', async (req, res) => {
    try {
        const result = await db.query(`
            SELECT m.*, ml.name as level_name 
            FROM masters m
            JOIN master_levels ml ON m.level_id = ml.id
            WHERE m.id = $1
        `, [req.params.id]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Мастер не найден' });
        }
        res.json(result.rows[0]);
    } catch (error) {
        res.status(500).json({ error: 'Ошибка получения мастера' });
    }
});

// ==================== ПОЛУЧИТЬ СВОБОДНОЕ ВРЕМЯ ====================
router.get('/:id/available', async (req, res) => {
    const { date } = req.query;
    const masterId = req.params.id;
    
    if (!date) {
        return res.status(400).json({ error: 'Дата обязательна' });
    }
    
    try {
        const bookedResult = await db.query(
            `SELECT appointment_time 
             FROM appointments 
             WHERE master_id = $1 AND appointment_date = $2`,
            [masterId, date]
        );
        
        const bookedTimes = bookedResult.rows.map(row => {
            const time = row.appointment_time;
            if (typeof time === 'string') return time.substring(0, 5);
            if (time instanceof Date) return time.toTimeString().substring(0, 5);
            return String(time).substring(0, 5);
        });
        
        const allSlots = [
            '09:00', '10:00', '11:00', '12:00', '13:00',
            '14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00'
        ];
        
        const availableSlots = allSlots.filter(slot => !bookedTimes.includes(slot));
        res.json(availableSlots);
    } catch (error) {
        res.status(500).json({ error: 'Ошибка получения расписания' });
    }
});

// ==================== ПОЛУЧИТЬ ВСЕ ОТЗЫВЫ О МАСТЕРЕ ====================
router.get('/:id/reviews', async (req, res) => {
    const masterId = req.params.id;
    
    try {
        // Получаем все отзывы
        const reviews = await db.query(`
            SELECT r.*, c.name as client_name
            FROM reviews r
            JOIN clients c ON r.client_id = c.id
            WHERE r.master_id = $1
            ORDER BY r.created_at DESC
        `, [masterId]);
        
        // Получаем средний рейтинг
        const stats = await db.query(`
            SELECT 
                COALESCE(AVG(rating), 0) as avg_rating,
                COUNT(*) as total
            FROM reviews
            WHERE master_id = $1
        `, [masterId]);
        
        res.json({
            average_rating: parseFloat(stats.rows[0].avg_rating).toFixed(1),
            total_reviews: parseInt(stats.rows[0].total),
            reviews: reviews.rows
        });
    } catch (error) {
        console.error('Ошибка получения отзывов:', error);
        res.status(500).json({ error: 'Ошибка получения отзывов' });
    }
});

// ==================== ДОБАВИТЬ ОТЗЫВ (ВСЕГДА НОВЫЙ) ====================
router.post('/:id/reviews', authenticateToken, async (req, res) => {
    const masterId = req.params.id;
    const clientId = req.user.client_id;
    const { rating, comment } = req.body;
    
    console.log(`📝 ДОБАВЛЕНИЕ НОВОГО ОТЗЫВА: мастер=${masterId}, клиент=${clientId}, оценка=${rating}`);
    
    if (!rating || rating < 1 || rating > 5) {
        return res.status(400).json({ error: 'Рейтинг должен быть от 1 до 5' });
    }
    
    if (!clientId) {
        return res.status(400).json({ error: 'Клиент не найден' });
    }
    
    try {
        // ВСЕГДА ВСТАВЛЯЕМ НОВУЮ СТРОКУ, НИЧЕГО НЕ ПРОВЕРЯЕМ
        const result = await db.query(
            `INSERT INTO reviews (master_id, client_id, rating, comment) 
             VALUES ($1, $2, $3, $4) 
             RETURNING id`,
            [masterId, clientId, rating, comment || null]
        );
        
        console.log(`✅ НОВЫЙ отзыв добавлен! ID=${result.rows[0].id}`);
        res.json({ 
            success: true, 
            message: 'Отзыв добавлен! Спасибо!',
            review_id: result.rows[0].id
        });
    } catch (error) {
        console.error('❌ Ошибка:', error);
        res.status(500).json({ error: 'Ошибка добавления отзыва: ' + error.message });
    }
});

module.exports = router;