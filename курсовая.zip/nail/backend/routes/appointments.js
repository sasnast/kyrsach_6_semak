const express = require('express');
const db = require('../db');
const { authenticateToken } = require('../middleware/auth');
const router = express.Router();

// ==================== СОЗДАТЬ ЗАПИСЬ (С ПЕРЕДАЧЕЙ ЦЕНЫ) ====================
router.post('/', authenticateToken, async (req, res) => {
    const { master_id, service_id, extra_service_ids, appointment_date, appointment_time } = req.body;
    const client_id = req.user.client_id;
    
    console.log('📝 Создание записи:', { master_id, service_id, appointment_date, appointment_time, client_id });
    
    if (!master_id || !service_id || !appointment_date || !appointment_time) {
        return res.status(400).json({ error: 'Не все поля заполнены' });
    }
    
    if (!client_id) {
        return res.status(400).json({ error: 'Клиент не найден' });
    }
    
    try {
        // Проверка на занятость
        const existing = await db.query(
            `SELECT id FROM appointments WHERE master_id = $1 AND appointment_date = $2 AND appointment_time = $3`,
            [master_id, appointment_date, appointment_time]
        );
        
        if (existing.rows.length > 0) {
            return res.status(400).json({ error: 'Время уже занято' });
        }
        
        // Получаем уровень мастера
        const masterLevel = await db.query(`SELECT level_id FROM masters WHERE id = $1`, [master_id]);
        const levelId = masterLevel.rows[0].level_id;
        
        // Получаем цену услуги
        const servicePrice = await db.query(
            `SELECT price FROM prices WHERE service_id = $1 AND level_id = $2`,
            [service_id, levelId]
        );
        let totalPrice = parseFloat(servicePrice.rows[0].price) || 0;
        
        // Добавляем стоимость доп. услуг
        if (extra_service_ids && extra_service_ids.length > 0) {
            for (const extra_id of extra_service_ids) {
                const extraPrice = await db.query(`SELECT price FROM extra_services WHERE id = $1`, [extra_id]);
                totalPrice += parseFloat(extraPrice.rows[0].price) || 0;
            }
        }
        
        console.log(`💰 Исходная цена: ${totalPrice}₽`);
        
        // Создаем запись (триггер сам применит скидку)
        const result = await db.query(
            `INSERT INTO appointments (client_id, master_id, appointment_date, appointment_time, status, total_price)
             VALUES ($1, $2, $3, $4, 'Запланирована', $5)
             RETURNING id, total_price, discount_applied`,
            [client_id, master_id, appointment_date, appointment_time, totalPrice]
        );
        
        const appointment_id = result.rows[0].id;
        const finalPrice = result.rows[0].total_price;
        const discountApplied = result.rows[0].discount_applied;
        
        console.log(`✅ Запись создана: ID=${appointment_id}, итого=${finalPrice}₽, скидка=${discountApplied}%`);
        
        // Добавляем услугу
        await db.query(
            `INSERT INTO appointment_services (appointment_id, service_id) VALUES ($1, $2)`,
            [appointment_id, service_id]
        );
        
        // Добавляем доп. услуги
        if (extra_service_ids && extra_service_ids.length > 0) {
            for (const extra_id of extra_service_ids) {
                await db.query(
                    `INSERT INTO appointment_extra_services (appointment_id, extra_service_id) VALUES ($1, $2)`,
                    [appointment_id, extra_id]
                );
            }
        }
        
        res.json({ 
            success: true, 
            appointment_id,
            total_price: finalPrice,
            discount_applied: discountApplied,
            message: 'Запись создана' 
        });
    } catch (error) {
        console.error('Ошибка:', error);
        res.status(500).json({ error: error.message });
    }
});

// ==================== ПОЛУЧИТЬ МОИ ЗАПИСИ ====================
// ==================== ПОЛУЧИТЬ МОИ ЗАПИСИ (СНАЧАЛА НОВЫЕ) ====================
// ==================== ПОЛУЧИТЬ МОИ ЗАПИСИ ====================
// ==================== ПОЛУЧИТЬ МОИ ЗАПИСИ ====================
// ==================== ПОЛУЧИТЬ МОИ ЗАПИСИ (ВАРИАНТ 2) ====================
// ==================== ПОЛУЧИТЬ МОИ ЗАПИСИ ====================
// ==================== ПОЛУЧИТЬ МОИ ЗАПИСИ (С УЧЕТОМ СКИДКИ) ====================
router.get('/my', authenticateToken, async (req, res) => {
    const client_id = req.user.client_id;
    
    if (!client_id) {
        return res.status(400).json({ error: 'Клиент не найден' });
    }
    
    try {
        const result = await db.query(`
            SELECT 
                a.id,
                TO_CHAR(a.appointment_date, 'DD.MM.YYYY') as appointment_date,
                TO_CHAR(a.appointment_time, 'HH24:MI') as appointment_time,
                a.status,
                a.total_price,
                a.discount_applied,
                m.name as master_name,
                s.name as service_name,
                STRING_AGG(DISTINCT es.name, ', ') as extra_services
            FROM appointments a
            JOIN masters m ON a.master_id = m.id
            JOIN appointment_services app_s ON a.id = app_s.appointment_id
            JOIN services s ON app_s.service_id = s.id
            LEFT JOIN appointment_extra_services app_es ON a.id = app_es.appointment_id
            LEFT JOIN extra_services es ON app_es.extra_service_id = es.id
            WHERE a.client_id = $1
            GROUP BY a.id, a.appointment_date, a.appointment_time, a.status, a.total_price, a.discount_applied, m.name, s.name
            ORDER BY a.appointment_date DESC, a.appointment_time DESC
        `, [client_id]);
        
        res.json(result.rows);
    } catch (error) {
        console.error('Ошибка:', error);
        res.status(500).json({ error: error.message });
    }
});
// ==================== ОТМЕНИТЬ ЗАПИСЬ ====================
router.put('/:id/cancel', authenticateToken, async (req, res) => {
    const { id } = req.params;
    const client_id = req.user.client_id;
    
    try {
        const result = await db.query(
            `UPDATE appointments SET status = 'Отменена'
             WHERE id = $1 AND client_id = $2 AND status = 'Запланирована'
             RETURNING id`,
            [id, client_id]
        );
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Запись не найдена' });
        }
        
        res.json({ success: true, message: 'Запись отменена' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;