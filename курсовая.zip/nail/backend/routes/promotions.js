const express = require('express');
const db = require('../db');
const router = express.Router();

// Получить все активные акции с описанием и условиями
router.get('/', async (req, res) => {
    try {
        const result = await db.query(`
            SELECT 
                id,
                name,
                discount_percent,
                promotion_type,
                start_date,
                end_date,
                start_time,
                end_time,
                CASE 
                    WHEN promotion_type = 'new_client' THEN '🎁 Скидка для новых клиентов!'
                    WHEN promotion_type = 'happy_hours' THEN '⏰ Счастливые часы'
                    WHEN promotion_type = 'seasonal' THEN '🌸 Весенняя распродажа'
                    ELSE name
                END as description,
                CASE 
                    WHEN promotion_type = 'happy_hours' AND start_time IS NOT NULL AND end_time IS NOT NULL 
                        THEN CONCAT('🕐 С ', TO_CHAR(start_time, 'HH24:MI'), ' до ', TO_CHAR(end_time, 'HH24:MI'))
                    WHEN promotion_type = 'seasonal' AND start_date IS NOT NULL AND end_date IS NOT NULL 
                        THEN CONCAT('📅 С ', TO_CHAR(start_date, 'DD.MM.YYYY'), ' по ', TO_CHAR(end_date, 'DD.MM.YYYY'))
                    WHEN promotion_type = 'new_client' 
                        THEN '🎉 Первая запись в студии'
                    ELSE NULL
                END as conditions
            FROM promotions 
            WHERE is_active = true 
            ORDER BY discount_percent DESC
        `);
        
        res.json(result.rows);
    } catch (error) {
        console.error('Ошибка получения акций:', error);
        res.status(500).json({ error: 'Ошибка получения акций' });
    }
});

module.exports = router;