const express = require('express');
const db = require('../db');
const router = express.Router();

// ==================== ПОЛУЧИТЬ ВСЕ УСЛУГИ ====================
router.get('/', async (req, res) => {
    console.log('📋 Запрос списка услуг');
    
    try {
        const result = await db.query(`
            SELECT s.*, 
                COALESCE(
                    (SELECT json_agg(
                        json_build_object(
                            'level_id', p.level_id, 
                            'level_name', ml.name, 
                            'price', p.price
                        )
                    ) FROM prices p 
                    LEFT JOIN master_levels ml ON p.level_id = ml.id 
                    WHERE p.service_id = s.id),
                    '[]'::json
                ) as prices
            FROM services s
            ORDER BY s.id
        `);
        
        console.log(`✅ Найдено услуг: ${result.rows.length}`);
        res.json(result.rows);
        
    } catch (error) {
        console.error('❌ Ошибка получения услуг:', error);
        res.status(500).json({ error: 'Ошибка получения услуг: ' + error.message });
    }
});

// ==================== ПОЛУЧИТЬ ДОПОЛНИТЕЛЬНЫЕ УСЛУГИ ====================
router.get('/extra', async (req, res) => {
    console.log('📋 Запрос дополнительных услуг');
    
    try {
        const result = await db.query(
            'SELECT * FROM extra_services ORDER BY name'
        );
        
        console.log(`✅ Найдено доп. услуг: ${result.rows.length}`);
        res.json(result.rows);
        
    } catch (error) {
        console.error('❌ Ошибка получения доп. услуг:', error);
        res.status(500).json({ error: 'Ошибка получения дополнительных услуг' });
    }
});

// ==================== ПОЛУЧИТЬ ЦЕНУ УСЛУГИ ====================
router.get('/price/:serviceId/:levelId', async (req, res) => {
    const { serviceId, levelId } = req.params;
    console.log(`💰 Запрос цены: услуга ${serviceId}, уровень ${levelId}`);
    
    try {
        const result = await db.query(
            `SELECT price FROM prices 
             WHERE service_id = $1 AND level_id = $2`,
            [serviceId, levelId]
        );
        
        if (result.rows.length === 0) {
            console.log(`❌ Цена не найдена`);
            return res.status(404).json({ error: 'Цена не найдена' });
        }
        
        console.log(`✅ Цена: ${result.rows[0].price}₽`);
        res.json({ price: result.rows[0].price });
        
    } catch (error) {
        console.error('❌ Ошибка получения цены:', error);
        res.status(500).json({ error: 'Ошибка получения цены' });
    }
});

module.exports = router;