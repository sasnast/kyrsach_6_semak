const express = require('express');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

// Подключаем маршруты
const authRoutes = require('./routes/auth');
const mastersRoutes = require('./routes/masters');
const servicesRoutes = require('./routes/services');
const appointmentsRoutes = require('./routes/appointments');
const promotionsRoutes = require('./routes/promotions');
const adminRoutes = require('./routes/admin');

const app = express();
const PORT = process.env.PORT || 3036;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Логирование запросов
app.use((req, res, next) => {
    console.log(`${req.method} ${req.url}`);
    next();
});

// Статические файлы
app.use(express.static(path.join(__dirname, '../frontend')));

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/masters', mastersRoutes);
app.use('/api/services', servicesRoutes);
app.use('/api/appointments', appointmentsRoutes);
app.use('/api/promotions', promotionsRoutes);
app.use('/api/admin', adminRoutes);

// Тестовый маршрут для проверки API
app.get('/api/test', (req, res) => {
    res.json({ 
        message: 'API работает!',
        time: new Date().toISOString(),
        endpoints: {
            services: '/api/services',
            masters: '/api/masters',
            promotions: '/api/promotions',
            auth: '/api/auth/login',
            register: '/api/auth/register'
        }
    });
});

// Все остальные маршруты - отдаем index.html
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

// Обработка ошибок
app.use((err, req, res, next) => {
    console.error('Ошибка:', err);
    res.status(500).json({ error: 'Внутренняя ошибка сервера' });
});

app.listen(PORT, () => {
    console.log(`
    ╔═══════════════════════════════════════════════════════╗
    ║                                                       ║
    ║   🎀  ROSE NAIL STUDIO  🎀                           ║
    ║                                                       ║
    ║   ✅ Сервер успешно запущен!                          ║
    ║   🌐 Порт: ${PORT}                                    ║
    ║   🔗 Ссылка: http://localhost:${PORT}                 ║
    ║                                                       ║
    ║   📡 Доступные API эндпоинты:                         ║
    ║   • GET  /api/test - проверка API                    ║
    ║   • POST /api/auth/register - регистрация            ║
    ║   • POST /api/auth/login - вход                      ║
    ║   • GET  /api/services - услуги                      ║
    ║   • GET  /api/masters - мастера                      ║
    ║   • GET  /api/promotions - акции                     ║
    ║                                                       ║
    ╚═══════════════════════════════════════════════════════╝
    `);
});