const jwt = require('jsonwebtoken');

// Проверка токена
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        console.log('❌ Нет токена в запросе');
        return res.status(401).json({ error: 'Требуется авторизация' });
    }

    jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
        if (err) {
            console.log('❌ Неверный токен:', err.message);
            return res.status(403).json({ error: 'Недействительный токен' });
        }
        console.log('✅ Пользователь авторизован:', user.login);
        req.user = user;
        next();
    });
};

// Проверка прав администратора
const isAdmin = (req, res, next) => {
    if (!req.user || req.user.role_id !== 1) {
        console.log('❌ Доступ запрещен: нет прав администратора');
        return res.status(403).json({ error: 'Доступ запрещен. Требуются права администратора' });
    }
    console.log('✅ Права администратора подтверждены');
    next();
};

module.exports = { authenticateToken, isAdmin };