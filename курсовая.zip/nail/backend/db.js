const { Pool } = require('pg');
require('dotenv').config();

// Подключение к PostgreSQL
const pool = new Pool({
    user: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASSWORD || '5174',
    host: process.env.DB_HOST || 'localhost',
    port: process.env.DB_PORT || 5432,
    database: process.env.DB_NAME || 'kursach',
    max: 20,
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 5000,
});

// Функция для выполнения запросов с логированием
const query = async (text, params) => {
    const start = Date.now();
    try {
        const res = await pool.query(text, params);
        const duration = Date.now() - start;
        console.log(`📊 SQL запрос (${duration}ms): ${text.substring(0, 100)}...`);
        return res;
    } catch (error) {
        console.error(`❌ Ошибка SQL: ${error.message}`);
        console.error(`   Запрос: ${text}`);
        throw error;
    }
};

// Проверка подключения
pool.connect((err, client, release) => {
    if (err) {
        console.error('❌ Ошибка подключения к PostgreSQL:', err.message);
        console.error('   Проверьте:');
        console.error('   1. Запущен ли PostgreSQL?');
        console.error('   2. Правильный ли пароль в .env?');
        console.error('   3. Существует ли база данных?');
    } else {
        console.log('✅ Успешно подключено к PostgreSQL');
        release();
    }
});

module.exports = {
    query,
    pool
};