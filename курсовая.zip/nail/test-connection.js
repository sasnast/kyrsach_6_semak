const { Client } = require('pg');
require('dotenv').config();

const client = new Client({
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    host: process.env.DB_HOST,
    port: process.env.DB_PORT,
    database: process.env.DB_NAME,
});

async function test() {
    try {
        await client.connect();
        console.log('✅ ПОДКЛЮЧЕНО К POSTGRESQL!');
        
        const res = await client.query('SELECT COUNT(*) FROM users');
        console.log('📊 Количество пользователей:', res.rows[0].count);
        
        await client.end();
    } catch (err) {
        console.error('❌ ОШИБКА ПОДКЛЮЧЕНИЯ:', err.message);
        console.error('Проверьте:');
        console.error('1. Запущен ли PostgreSQL?');
        console.error('2. Правильный ли пароль в .env?');
        console.error('3. Правильное ли имя базы данных?');
    }
}

test();